# Sports BoX — First Play Ad Update

- Keeps the existing Adsterra ad integrations.
- Shows the existing Adsterra banner unit on the first-play 10-second countdown screen.
- The countdown continues independently; after 10 seconds the selected player opens automatically.
- No ad click, SmartLink visit, or user interaction is required to continue.
- The banner is subject to Adsterra ad fill and network availability; an ad is not guaranteed on every request.

Build note: the source archive does not contain a `gradlew` wrapper script. Add/restore the Gradle wrapper or use a workflow that installs a compatible Gradle version before building.
