package com.example

import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.model.LiveChannel
import com.example.ui.components.AddCustomStreamDialog
import com.example.ui.components.AdsterraBannerAd
import com.example.ui.components.FloatingBottomNavBar
import com.example.ui.components.FloatingNavItem
import com.example.ui.components.SportsBoxDrawerContent
import com.example.ui.components.SportsBoxTopBar
import com.example.ui.components.openAdsterraSmartLink
import com.example.ui.navigation.AdminControlRoute
import com.example.ui.navigation.ChannelsRoute
import com.example.ui.navigation.HighlightsRoute
import com.example.ui.navigation.LiveMatchesRoute
import com.example.ui.navigation.PlayerRoute
import com.example.ui.screens.AdminControlScreen
import com.example.ui.screens.ChannelsScreen
import com.example.ui.screens.HighlightsScreen
import com.example.ui.screens.LiveMatchesScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.JtvSportsTheme
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
    )
    setContent {
      JtvSportsTheme {
        SportsBoxBoxApp()
      }
    }
  }
}

@Composable
fun SportsBoxBoxApp(viewModel: MainViewModel = viewModel()) {
  val context = LocalContext.current
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = navBackStackEntry?.destination
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()

  val channelsState by viewModel.channelsState.collectAsStateWithLifecycle()
  val matchesState by viewModel.matchesState.collectAsStateWithLifecycle()
  val allChannels by viewModel.allChannels.collectAsStateWithLifecycle()
  val filteredChannels by viewModel.filteredChannels.collectAsStateWithLifecycle()
  val categories by viewModel.channelCategories.collectAsStateWithLifecycle()
  val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
  val recentIds by viewModel.recentIds.collectAsStateWithLifecycle()
  val selectedMatchTab by viewModel.selectedMatchTab.collectAsStateWithLifecycle()
  val selectedMatchSport by viewModel.selectedMatchSport.collectAsStateWithLifecycle()
  val matchSearchQuery by viewModel.matchSearchQuery.collectAsStateWithLifecycle()
  val selectedChannelCategory by viewModel.selectedChannelCategory.collectAsStateWithLifecycle()
  val channelSearchQuery by viewModel.channelSearchQuery.collectAsStateWithLifecycle()
  val favoritesOnly by viewModel.favoritesOnlyFilter.collectAsStateWithLifecycle()
  val activePlayable by viewModel.activePlayable.collectAsStateWithLifecycle()
  val adminToken by viewModel.adminToken.collectAsStateWithLifecycle()
  val adminChannels by viewModel.adminChannels.collectAsStateWithLifecycle()
  val adminStatus by viewModel.adminStatus.collectAsStateWithLifecycle()
  val adminBusy by viewModel.adminBusy.collectAsStateWithLifecycle()

  var showAddStreamDialog by remember { mutableStateOf(false) }
  var matchSearchVisible by remember { mutableStateOf(false) }
  var infoDialogContent by remember { mutableStateOf<Pair<String, String>?>(null) }
  var pendingFirstPlayChannel by remember { mutableStateOf<LiveChannel?>(null) }

  val navigateToPlayer: (LiveChannel) -> Unit = { channel ->
    viewModel.setPlayableChannel(channel)
    navController.navigate(PlayerRoute(channelId = channel.id)) {
      launchSingleTop = true
    }
  }

  val openPlayer: (LiveChannel) -> Unit = { channel ->
    val firstPlayPrefs = context.getSharedPreferences("sports_box_first_play", android.content.Context.MODE_PRIVATE)
    val alreadyShown = firstPlayPrefs.getBoolean("first_play_sponsor_screen_done", false)
    if (viewModel.shouldTriggerSmartAdOnOpen()) {
      openAdsterraSmartLink(context)
    }
    if (alreadyShown) {
      navigateToPlayer(channel)
    } else if (pendingFirstPlayChannel == null) {
      pendingFirstPlayChannel = channel
    }
  }

  val isPlayerScreen = currentDestination?.hasRoute<PlayerRoute>() == true
  val isAdminScreen = currentDestination?.hasRoute<AdminControlRoute>() == true
  val showChrome = !isPlayerScreen && !isAdminScreen

  val navigateToTab: (Any) -> Unit = { route ->
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) {
        saveState = true
      }
      launchSingleTop = true
      restoreState = true
    }
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    gesturesEnabled = showChrome,
    drawerContent = {
      SportsBoxDrawerContent(
        onNavigateLive = {
          scope.launch { drawerState.close() }
          navigateToTab(LiveMatchesRoute)
        },
        onNavigateChannels = {
          scope.launch { drawerState.close() }
          navigateToTab(ChannelsRoute)
        },
        onNavigateHighlights = {
          scope.launch { drawerState.close() }
          navigateToTab(HighlightsRoute)
        },
        onOpenAdminControl = {
          scope.launch { drawerState.close() }
          viewModel.clearAdminStatus()
          navController.navigate(AdminControlRoute) { launchSingleTop = true }
        },
        onOpenInfoDialog = { title, msg ->
          scope.launch { drawerState.close() }
          infoDialogContent = title to msg
        },
        onShareApp = {
          scope.launch { drawerState.close() }
          val shareIntent =
            Intent(Intent.ACTION_SEND).apply {
              type = "text/plain"
              putExtra(
                Intent.EXTRA_TEXT,
                "Watch Live Cricket, Football & TV Channels on Sports BoX! https://jtvsports24.blogspot.com",
              )
            }
          context.startActivity(Intent.createChooser(shareIntent, "Share Sports BoX"))
        },
        onOpenTelegram = {
          scope.launch { drawerState.close() }
          runCatching {
            context.startActivity(
              Intent(Intent.ACTION_VIEW, Uri.parse("https://jtvsports24.blogspot.com")),
            )
          }
        },
      )
    },
  ) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val useRail = maxWidth >= 680.dp && showChrome

      val navItems =
        listOf(
          FloatingNavItem(
            label = stringResource(R.string.nav_live),
            icon = Icons.Filled.LiveTv,
            selected = currentDestination?.hasRoute<LiveMatchesRoute>() == true,
            testTag = "nav_tab_live",
            onClick = { navigateToTab(LiveMatchesRoute) },
          ),
          FloatingNavItem(
            label = stringResource(R.string.nav_channel),
            icon = Icons.Filled.Tv,
            selected = currentDestination?.hasRoute<ChannelsRoute>() == true,
            testTag = "nav_tab_channel",
            onClick = { navigateToTab(ChannelsRoute) },
          ),
          FloatingNavItem(
            label = stringResource(R.string.nav_highlights),
            icon = Icons.Filled.PlayCircle,
            selected = currentDestination?.hasRoute<HighlightsRoute>() == true,
            testTag = "nav_tab_highlights",
            onClick = { navigateToTab(HighlightsRoute) },
          ),
        )

      Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
      ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
          Row(modifier = Modifier.fillMaxSize()) {
            if (useRail) {
              NavigationRail(
                modifier = Modifier.fillMaxHeight().windowInsetsPadding(WindowInsets.statusBars),
                containerColor = MaterialTheme.colorScheme.surface,
              ) {
                navItems.forEach { item ->
                  NavigationRailItem(
                    selected = item.selected,
                    onClick = item.onClick,
                    modifier = Modifier.testTag(item.testTag),
                    icon = { Icon(item.icon, contentDescription = item.label) },
                    label = { Text(item.label) },
                    colors =
                      NavigationRailItemDefaults.colors(
                        selectedIconColor = ElectricEmerald,
                        selectedTextColor = ElectricEmerald,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                      ),
                  )
                }
              }
            }

            Column(
              modifier =
                Modifier.weight(1f)
                  .fillMaxHeight()
                  .then(
                    if (isPlayerScreen) Modifier
                    else Modifier.windowInsetsPadding(WindowInsets.statusBars),
                  ),
            ) {
              if (showChrome) {
                SportsBoxTopBar(
                  onMenuClick = { scope.launch { drawerState.open() } },
                  onSearchClick = {
                    if (currentDestination?.hasRoute<LiveMatchesRoute>() == true) {
                      matchSearchVisible = !matchSearchVisible
                    } else {
                      navigateToTab(ChannelsRoute)
                    }
                  },
                  onRefreshClick = { viewModel.refreshAll(showLoadingIfEmpty = true) },
                )
              }

              Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                NavHost(
                  navController = navController,
                  startDestination = LiveMatchesRoute,
                  modifier = Modifier.fillMaxSize(),
                ) {
                  composable<LiveMatchesRoute> {
                    LiveMatchesScreen(
                      matchesState = matchesState,
                      selectedTab = selectedMatchTab,
                      selectedSport = selectedMatchSport,
                      searchVisible = matchSearchVisible,
                      searchQuery = matchSearchQuery,
                      onTabSelected = viewModel::selectMatchTab,
                      onSportSelected = viewModel::selectMatchSport,
                      onSearchQueryChanged = viewModel::updateMatchSearch,
                      onMatchClick = { match ->
                        val playable = viewModel.playableFromMatch(match)
                        if (playable != null) {
                          openPlayer(playable)
                        } else {
                          navigateToTab(ChannelsRoute)
                        }
                      },
                      onRetry = { viewModel.refreshMatches(showLoading = true) },
                    )
                  }

                  composable<ChannelsRoute> {
                    ChannelsScreen(
                      channelsState = channelsState,
                      allChannels = allChannels,
                      filteredChannels = filteredChannels,
                      categories = categories,
                      favoriteIds = favoriteIds,
                      selectedCategory = selectedChannelCategory,
                      searchQuery = channelSearchQuery,
                      favoritesOnly = favoritesOnly,
                      onSelectCategory = viewModel::selectChannelCategory,
                      onSearchQueryChanged = viewModel::updateChannelSearch,
                      onToggleFavoritesOnly = viewModel::toggleFavoritesOnlyFilter,
                      onChannelClick = openPlayer,
                      onToggleFavorite = viewModel::toggleFavorite,
                      onRetry = { viewModel.refreshChannels(showLoading = true) },
                    )
                  }

                  composable<HighlightsRoute> {
                    HighlightsScreen(
                      allChannels = allChannels,
                      matchesState = matchesState,
                      favoriteIds = favoriteIds,
                      recentIds = recentIds,
                      onChannelClick = openPlayer,
                      onMatchClick = { match ->
                        val playable = viewModel.playableFromMatch(match)
                        if (playable != null) openPlayer(playable)
                      },
                      onToggleFavorite = viewModel::toggleFavorite,
                      onDeleteCustomStream = viewModel::removeCustomStream,
                      onAddStreamClick = { showAddStreamDialog = true },
                    )
                  }

                  composable<PlayerRoute> { backStackEntry ->
                    val route = backStackEntry.toRoute<PlayerRoute>()
                    val target =
                      activePlayable?.takeIf { it.id == route.channelId }
                        ?: allChannels.firstOrNull { it.id == route.channelId }
                        ?: allChannels.firstOrNull()
                    if (target != null) {
                      PlayerScreen(
                        channel = target,
                        allChannels = allChannels,
                        favoriteIds = favoriteIds,
                        onBackClick = { navController.popBackStack() },
                        onSelectChannel = { next ->
                          viewModel.setPlayableChannel(next)
                          navController.navigate(PlayerRoute(channelId = next.id)) {
                            popUpTo<PlayerRoute> { inclusive = true }
                          }
                        },
                        onToggleFavorite = viewModel::toggleFavorite,
                      )
                    }
                  }

                  composable<AdminControlRoute> {
                    AdminControlScreen(
                      adminToken = adminToken,
                      adminChannels = adminChannels,
                      matchesState = matchesState,
                      adminStatus = adminStatus,
                      adminBusy = adminBusy,
                      onBackClick = { navController.popBackStack() },
                      onLogin = viewModel::adminLogin,
                      onLogout = viewModel::adminLogout,
                      onLoadAdminChannels = { viewModel.loadAdminChannels() },
                      onSaveChannel = viewModel::adminSaveChannel,
                      onDeleteChannel = viewModel::adminDeleteChannel,
                      onAddMatch = viewModel::adminAddMatch,
                      onDeleteMatch = viewModel::adminDeleteMatch,
                    )
                  }
                }
              }
            }
          }

          if (showChrome && !useRail) {
            FloatingBottomNavBar(
              items = navItems,
              modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter),
            )
          }

          pendingFirstPlayChannel?.let { firstChannel ->
            FirstPlaySponsorCountdown(
              onFinished = {
                context.getSharedPreferences("sports_box_first_play", android.content.Context.MODE_PRIVATE)
                  .edit()
                  .putBoolean("first_play_sponsor_screen_done", true)
                  .apply()
                pendingFirstPlayChannel = null
                navigateToPlayer(firstChannel)
              },
            )
          }
        }
      }
    }
  }

  if (showAddStreamDialog) {
    AddCustomStreamDialog(
      onDismiss = { showAddStreamDialog = false },
      onSaveAndWatch = { name, url, category ->
        showAddStreamDialog = false
        viewModel.addCustomStream(name, url, category) { created ->
          openPlayer(created)
        }
      },
    )
  }

  infoDialogContent?.let { (title, message) ->
    AlertDialog(
      onDismissRequest = { infoDialogContent = null },
      containerColor = MaterialTheme.colorScheme.surface,
      title = { Text(title, style = MaterialTheme.typography.headlineSmall) },
      text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
      confirmButton = {
        TextButton(onClick = { infoDialogContent = null }) {
          Text("OK", color = ElectricEmerald)
        }
      },
    )
  }
}


@Composable
private fun FirstPlaySponsorCountdown(
  onFinished: () -> Unit,
) {
  var secondsLeft by remember { mutableIntStateOf(10) }

  LaunchedEffect(Unit) {
    for (second in 10 downTo 1) {
      secondsLeft = second
      delay(1_000L)
    }
    onFinished()
  }

  androidx.compose.material3.Surface(
    modifier = Modifier.fillMaxSize(),
    color = Color(0xFF07111F),
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(28.dp),
      horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Text(
        text = "SPORTS BoX",
        style = MaterialTheme.typography.headlineMedium,
        color = Color(0xFFB7F34A),
        fontWeight = FontWeight.Bold,
      )
      Text(
        text = "প্রথমবার ভিডিও চালুর প্রস্তুতি",
        modifier = Modifier.padding(top = 18.dp),
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
      )
      Text(
        text = "SPONSORED",
        modifier = Modifier.padding(top = 22.dp, bottom = 8.dp),
        style = MaterialTheme.typography.labelSmall,
        color = Color.White.copy(alpha = 0.65f),
      )
      AdsterraBannerAd(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
      )
      CircularProgressIndicator(
        progress = secondsLeft / 10f,
        modifier = Modifier.padding(top = 28.dp).size(76.dp),
        color = Color(0xFFB7F34A),
        trackColor = Color.White.copy(alpha = 0.18f),
        strokeWidth = 6.dp,
      )
      Text(
        text = "$secondsLeft",
        modifier = Modifier.padding(top = 14.dp),
        fontSize = 42.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White,
      )
      Text(
        text = "সেকেন্ড পর ভিডিও স্বয়ংক্রিয়ভাবে চালু হবে",
        modifier = Modifier.padding(top = 8.dp),
        style = MaterialTheme.typography.bodyMedium,
        color = Color.White.copy(alpha = 0.75f),
      )
    }
  }
}
