package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.LiveChannel
import com.example.data.model.MatchFixture
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.LiveCrimson
import com.example.ui.viewmodel.MatchesUiState

@Composable
fun AdminControlScreen(
  adminToken: String?,
  adminChannels: List<LiveChannel>,
  matchesState: MatchesUiState,
  adminStatus: String?,
  adminBusy: Boolean,
  onBackClick: () -> Unit,
  onLogin: (String) -> Unit,
  onLogout: () -> Unit,
  onLoadAdminChannels: () -> Unit,
  onSaveChannel: (
    existingId: String?,
    name: String,
    category: String,
    logoUrl: String,
    streamType: String,
    streamUrl: String,
    sortOrder: Int,
    enabled: Boolean,
  ) -> Unit,
  onDeleteChannel: (String) -> Unit,
  onAddMatch: (
    title: String,
    league: String,
    team1: String,
    team1Logo: String,
    team2: String,
    team2Logo: String,
    matchTime: String,
    status: String,
    streamType: String,
    streamUrl: String,
  ) -> Unit,
  onDeleteMatch: (String) -> Unit,
) {
  LaunchedEffect(adminToken) {
    if (!adminToken.isNullOrBlank()) {
      onLoadAdminChannels()
    }
  }

  var activeTab by remember { mutableIntStateOf(0) } // 0 = TV Channels, 1 = Matches
  var password by remember { mutableStateOf("") }

  // Channel form state
  var editingChannelId by remember { mutableStateOf<String?>(null) }
  var chName by remember { mutableStateOf("") }
  var chCategory by remember { mutableStateOf("Bangladesh") }
  var chLogo by remember { mutableStateOf("") }
  var chType by remember { mutableStateOf("m3u8") }
  var chUrl by remember { mutableStateOf("") }
  var chSort by remember { mutableStateOf("0") }
  var chEnabled by remember { mutableStateOf(true) }

  // Match form state
  var mTitle by remember { mutableStateOf("") }
  var mLeague by remember { mutableStateOf("") }
  var mTeam1 by remember { mutableStateOf("") }
  var mTeam1Logo by remember { mutableStateOf("") }
  var mTeam2 by remember { mutableStateOf("") }
  var mTeam2Logo by remember { mutableStateOf("") }
  var mTime by remember { mutableStateOf("") }
  var mStatus by remember { mutableStateOf("live") }
  var mStreamType by remember { mutableStateOf("m3u8") }
  var mStreamUrl by remember { mutableStateOf("") }

  val matchesList = (matchesState as? MatchesUiState.Success)?.matches.orEmpty()

  Column(modifier = Modifier.fillMaxSize()) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onBackClick,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("admin_back_button"),
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
        }
        Column {
          Text(
            text = "J TV CONTROL PANEL",
            style = MaterialTheme.typography.headlineSmall,
          )
          Text(
            text = "Changes sync live to Website + Sports BoX",
            style = MaterialTheme.typography.labelSmall,
            color = ElectricEmerald,
          )
        }
      }

      if (!adminToken.isNullOrBlank()) {
        IconButton(
          onClick = onLogout,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("admin_logout_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Logout,
            contentDescription = "Logout",
            tint = LiveCrimson,
          )
        }
      }
    }

    if (adminToken.isNullOrBlank()) {
      Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.Center,
      ) {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.AdminPanelSettings,
                contentDescription = null,
                tint = ElectricEmerald,
              )
              Text(
                text = "Admin Login",
                style = MaterialTheme.typography.titleLarge,
              )
            }
            Text(
              text = "Sign in with your J TV Control API password to add or delete channels & matches for both Website and App.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
              value = password,
              onValueChange = { password = it },
              label = { Text("Admin password") },
              visualTransformation = PasswordVisualTransformation(),
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("admin_password_input"),
            )
            if (adminStatus != null) {
              Text(
                text = adminStatus,
                style = MaterialTheme.typography.bodyMedium,
                color = LiveCrimson,
              )
            }
            Button(
              onClick = { onLogin(password) },
              enabled = !adminBusy && password.isNotBlank(),
              modifier = Modifier.fillMaxWidth().testTag("admin_login_button"),
            ) {
              if (adminBusy) {
                CircularProgressIndicator(
                  modifier = Modifier.size(18.dp),
                  color = MaterialTheme.colorScheme.onPrimary,
                  strokeWidth = 2.dp,
                )
              } else {
                Text("Login & Sync")
              }
            }
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        item {
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(
              selected = activeTab == 0,
              onClick = { activeTab = 0 },
              leadingIcon = { Icon(Icons.Filled.LiveTv, contentDescription = null, modifier = Modifier.size(16.dp)) },
              label = { Text("LIVE TV (${adminChannels.size})") },
            )
            FilterChip(
              selected = activeTab == 1,
              onClick = { activeTab = 1 },
              leadingIcon = { Icon(Icons.Filled.SportsCricket, contentDescription = null, modifier = Modifier.size(16.dp)) },
              label = { Text("Matches (${matchesList.size})") },
            )
          }
        }

        if (adminStatus != null) {
          item {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
            ) {
              Text(
                text = adminStatus,
                style = MaterialTheme.typography.bodyMedium,
                color = ElectricEmerald,
                modifier = Modifier.fillMaxWidth().padding(12.dp),
              )
            }
          }
        }

        if (activeTab == 0) {
          item {
            Surface(
              shape = MaterialTheme.shapes.large,
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Text(
                  text = if (editingChannelId == null) "Add Live TV Channel" else "Edit Channel #$editingChannelId",
                  style = MaterialTheme.typography.titleMedium,
                )
                OutlinedTextField(
                  value = chName,
                  onValueChange = { chName = it },
                  label = { Text("Channel Name") },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                  value = chCategory,
                  onValueChange = { chCategory = it },
                  label = { Text("Category") },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                  value = chLogo,
                  onValueChange = { chLogo = it },
                  label = { Text("Logo URL (optional)") },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth(),
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  items(listOf("m3u8", "embed", "youtube")) { t ->
                    FilterChip(
                      selected = chType == t,
                      onClick = { chType = t },
                      label = { Text(t.uppercase()) },
                    )
                  }
                }
                OutlinedTextField(
                  value = chUrl,
                  onValueChange = { chUrl = it },
                  label = { Text("Stream URL / iframe HTML code") },
                  singleLine = true,
                  modifier = Modifier.fillMaxWidth(),
                )
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  OutlinedTextField(
                    value = chSort,
                    onValueChange = { chSort = it.filter { c -> c.isDigit() } },
                    label = { Text("Sort order") },
                    singleLine = true,
                    modifier = Modifier.width(120.dp),
                  )
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Enabled", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(checked = chEnabled, onCheckedChange = { chEnabled = it })
                  }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Button(
                    onClick = {
                      onSaveChannel(
                        editingChannelId,
                        chName.trim(),
                        chCategory.trim().ifBlank { "Bangladesh" },
                        chLogo.trim(),
                        chType,
                        chUrl.trim(),
                        chSort.toIntOrNull() ?: 0,
                        chEnabled,
                      )
                      editingChannelId = null
                      chName = ""
                      chLogo = ""
                      chUrl = ""
                    },
                    enabled = !adminBusy && chName.isNotBlank() && chUrl.isNotBlank(),
                  ) {
                    Text(if (editingChannelId == null) "Add Channel" else "Update Channel")
                  }
                  if (editingChannelId != null) {
                    OutlinedButton(
                      onClick = {
                        editingChannelId = null
                        chName = ""
                        chLogo = ""
                        chUrl = ""
                      },
                    ) {
                      Text(stringResource(R.string.cancel))
                    }
                  }
                }
              }
            }
          }

          items(items = adminChannels, key = { "adm_ch_${it.id}" }) { ch ->
            Surface(
              shape = MaterialTheme.shapes.medium,
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(ch.name, style = MaterialTheme.typography.titleSmall)
                  Text(
                    text = "${ch.category} · ${ch.streamType.name.lowercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricEmerald,
                  )
                  Text(
                    text = ch.streamUrl,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
                IconButton(
                  onClick = {
                    editingChannelId = ch.id
                    chName = ch.name
                    chCategory = ch.category
                    chLogo = ch.logoUrl.orEmpty()
                    chType = ch.streamType.name.lowercase()
                    chUrl = ch.streamUrl
                    chSort = ch.sortOrder.toString()
                    chEnabled = ch.enabled
                  },
                ) {
                  Icon(Icons.Filled.Edit, contentDescription = "Edit channel", tint = ElectricEmerald)
                }
                IconButton(onClick = { onDeleteChannel(ch.id) }) {
                  Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete channel", tint = LiveCrimson)
                }
              }
            }
          }
        } else {
          item {
            Surface(
              shape = MaterialTheme.shapes.large,
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Text("Add Live Match", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(value = mTitle, onValueChange = { mTitle = it }, label = { Text("Match Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = mLeague, onValueChange = { mLeague = it }, label = { Text("League") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  OutlinedTextField(value = mTeam1, onValueChange = { mTeam1 = it }, label = { Text("Team 1") }, singleLine = true, modifier = Modifier.weight(1f))
                  OutlinedTextField(value = mTeam2, onValueChange = { mTeam2 = it }, label = { Text("Team 2") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  OutlinedTextField(value = mTeam1Logo, onValueChange = { mTeam1Logo = it }, label = { Text("Team 1 Logo URL") }, singleLine = true, modifier = Modifier.weight(1f))
                  OutlinedTextField(value = mTeam2Logo, onValueChange = { mTeam2Logo = it }, label = { Text("Team 2 Logo URL") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = mTime, onValueChange = { mTime = it }, label = { Text("Match Time") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  items(listOf("live", "upcoming", "finished")) { st ->
                    FilterChip(selected = mStatus == st, onClick = { mStatus = st }, label = { Text(st.uppercase()) })
                  }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  items(listOf("m3u8", "embed", "youtube", "none")) { st ->
                    FilterChip(selected = mStreamType == st, onClick = { mStreamType = st }, label = { Text(st.uppercase()) })
                  }
                }
                OutlinedTextField(value = mStreamUrl, onValueChange = { mStreamUrl = it }, label = { Text("Stream URL / iframe HTML code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(
                  onClick = {
                    onAddMatch(
                      mTitle.trim(),
                      mLeague.trim(),
                      mTeam1.trim(),
                      mTeam1Logo.trim(),
                      mTeam2.trim(),
                      mTeam2Logo.trim(),
                      mTime.trim(),
                      mStatus,
                      mStreamType,
                      mStreamUrl.trim(),
                    )
                    mTitle = ""
                    mTeam1 = ""
                    mTeam2 = ""
                    mStreamUrl = ""
                  },
                  enabled = !adminBusy && mTitle.isNotBlank() && mTeam1.isNotBlank() && mTeam2.isNotBlank(),
                ) {
                  Text("Add Match")
                }
              }
            }
          }

          items(items = matchesList, key = { "adm_m_${it.id}" }) { m ->
            Surface(
              shape = MaterialTheme.shapes.medium,
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(m.title, style = MaterialTheme.typography.titleSmall)
                  Text(
                    text = "${m.team1} vs ${m.team2} · ${m.status.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
                IconButton(onClick = { onDeleteMatch(m.id) }) {
                  Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete match", tint = LiveCrimson)
                }
              }
            }
          }
        }
      }
    }
  }
}
