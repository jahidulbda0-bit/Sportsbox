package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sports
import androidx.compose.material.icons.filled.SportsBasketball
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.SportsMotorsports
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.MatchFilterTab
import com.example.data.model.MatchFixture
import com.example.data.model.MatchStatus
import com.example.ui.components.AdsterraBannerAd
import com.example.ui.components.MatchBroadcastCard
import com.example.ui.theme.BroadcastSlate
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.KriraLime
import com.example.ui.theme.LiveCrimson
import com.example.ui.theme.OutlineHighlight
import com.example.ui.viewmodel.MatchesUiState
import com.example.ui.viewmodel.matchesTab

private data class SportCircleItem(
  val key: String,
  val label: String,
  val icon: ImageVector,
)

@Composable
fun LiveMatchesScreen(
  matchesState: MatchesUiState,
  selectedTab: MatchFilterTab,
  selectedSport: String,
  searchVisible: Boolean,
  searchQuery: String,
  onTabSelected: (MatchFilterTab) -> Unit,
  onSportSelected: (String) -> Unit,
  onSearchQueryChanged: (String) -> Unit,
  onMatchClick: (MatchFixture) -> Unit,
  onRetry: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val allMatches = (matchesState as? MatchesUiState.Success)?.matches.orEmpty()

  val sportItems = remember {
    listOf(
      SportCircleItem("All", "All", Icons.Filled.Sports),
      SportCircleItem("Cricket", "Cricket", Icons.Filled.SportsCricket),
      SportCircleItem("Football", "Football", Icons.Filled.SportsSoccer),
      SportCircleItem("Basketball", "Basketball", Icons.Filled.SportsBasketball),
      SportCircleItem("Motorsport", "Motorsport", Icons.Filled.SportsMotorsports),
    )
  }

  val filteredMatches =
    remember(allMatches, selectedTab, selectedSport, searchQuery) {
      allMatches.filter { match ->
        val tabOk = match.matchesTab(selectedTab)
        val sportOk =
          selectedSport == "All" || match.sportCategory.equals(selectedSport, ignoreCase = true)
        val queryOk =
          searchQuery.isBlank() ||
            match.title.contains(searchQuery, ignoreCase = true) ||
            match.league.contains(searchQuery, ignoreCase = true) ||
            match.team1.contains(searchQuery, ignoreCase = true) ||
            match.team2.contains(searchQuery, ignoreCase = true)
        tabOk && sportOk && queryOk
      }
    }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val gridColumns = if (maxWidth >= 680.dp) 2 else 1

    LazyVerticalGrid(
      columns = GridCells.Fixed(gridColumns),
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 96.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item(span = { GridItemSpan(maxLineSpan) }) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          AnimatedVisibility(visible = searchVisible) {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = onSearchQueryChanged,
              modifier = Modifier.fillMaxWidth().testTag("match_search_input"),
              placeholder = { Text(stringResource(R.string.search_matches_hint)) },
              leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
              trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                  IconButton(onClick = { onSearchQueryChanged("") }) {
                    Icon(Icons.Filled.Clear, contentDescription = "Clear")
                  }
                }
              },
              singleLine = true,
              shape = RoundedCornerShape(14.dp),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = MaterialTheme.colorScheme.surface,
                  unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                ),
            )
          }

          // Top status filter strip (Next 24h, Live, Upcoming, End, All)
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = BroadcastSlate,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              MatchFilterTab.entries.forEach { tab ->
                val count = allMatches.count { it.matchesTab(tab) }
                val selected = tab == selectedTab
                Surface(
                  modifier =
                    Modifier.weight(1f)
                      .clip(RoundedCornerShape(10.dp))
                      .clickable { onTabSelected(tab) }
                      .testTag("match_tab_${tab.name}"),
                  shape = RoundedCornerShape(10.dp),
                  color =
                    if (selected) Color(0xFF132D2E) else Color.Transparent,
                  border =
                    if (selected) BorderStroke(1.dp, KriraLime.copy(alpha = 0.75f)) else null,
                ) {
                  Column(
                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                  ) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(3.dp),
                    ) {
                      if (tab == MatchFilterTab.LIVE) {
                        Box(
                          modifier =
                            Modifier.size(6.dp).clip(CircleShape).background(LiveCrimson),
                        )
                      }
                      Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) KriraLime else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                      )
                    }
                    Text(
                      text = "($count)",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (selected) KriraLime else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }
          }

          // Circular sport/league quick filters with count badge
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(horizontal = 2.dp),
          ) {
            items(sportItems, key = { it.key }, contentType = { "sport_filter" }) { item ->
              val count =
                if (item.key == "All") allMatches.size
                else allMatches.count { it.sportCategory.equals(item.key, ignoreCase = true) }
              val selected = selectedSport == item.key

              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier =
                  Modifier.width(72.dp)
                    .clickable { onSportSelected(item.key) }
                    .testTag("match_sport_circle_${item.key}"),
              ) {
                Box(contentAlignment = Alignment.TopEnd) {
                  Surface(
                    modifier = Modifier.size(52.dp),
                    shape = CircleShape,
                    color = if (selected) Color(0xFF172F35) else BroadcastSlate,
                    border =
                      BorderStroke(
                        width = if (selected) 2.dp else 1.dp,
                        color = if (selected) ElectricEmerald else OutlineHighlight,
                      ),
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (selected) ElectricEmerald else Color.White,
                        modifier = Modifier.size(24.dp),
                      )
                    }
                  }
                  Surface(
                    shape = CircleShape,
                    color = if (selected) ElectricEmerald else Color(0xFF28415F),
                    modifier = Modifier.size(20.dp),
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Text(
                        text = count.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold,
                      )
                    }
                  }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = item.label,
                  style = MaterialTheme.typography.bodyMedium,
                  color = if (selected) ElectricEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
        }
      }

      // Adsterra Banner inside Live Matches feed
      item(span = { GridItemSpan(maxLineSpan) }) {
        AdsterraBannerAd()
      }

      when (matchesState) {
        is MatchesUiState.Loading -> {
          item(span = { GridItemSpan(maxLineSpan) }) {
            Box(
              modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp),
              contentAlignment = Alignment.Center,
            ) {
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                CircularProgressIndicator(color = ElectricEmerald)
                Text(
                  text = "Syncing live matches…",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }

        is MatchesUiState.Error -> {
          item(span = { GridItemSpan(maxLineSpan) }) {
            Surface(
              shape = MaterialTheme.shapes.large,
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Icon(
                  imageVector = Icons.Filled.CloudOff,
                  contentDescription = null,
                  tint = LiveCrimson,
                  modifier = Modifier.size(38.dp),
                )
                Text(
                  text = "Unable to sync matches",
                  style = MaterialTheme.typography.titleMedium,
                )
                Text(
                  text = matchesState.message,
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  textAlign = TextAlign.Center,
                )
                Button(onClick = onRetry) {
                  Text(stringResource(R.string.retry))
                }
              }
            }
          }
        }

        is MatchesUiState.Success -> {
          if (filteredMatches.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
              Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
              ) {
                Column(
                  modifier = Modifier.fillMaxWidth().padding(28.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Icon(
                    imageVector = Icons.Filled.SportsSoccer,
                    contentDescription = null,
                    tint = ElectricEmerald,
                    modifier = Modifier.size(40.dp),
                  )
                  Text(
                    text = stringResource(R.string.no_matches_title),
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                  )
                  Text(
                    text = stringResource(R.string.no_matches_tip),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                  )
                }
              }
            }
          } else {
            items(items = filteredMatches, key = { it.id }, contentType = { "match" }) { match ->
              MatchBroadcastCard(
                match = match,
                onClick = { onMatchClick(match) },
              )
            }
          }
        }
      }
    }
  }
}
