package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.StreamPreferencesRepository
import com.example.data.model.ChannelCategorySummary
import com.example.data.model.LiveChannel
import com.example.data.model.MatchFilterTab
import com.example.data.model.MatchFixture
import com.example.data.model.MatchStatus
import com.example.data.model.StreamType
import com.example.data.remote.JtvControlApi
import com.example.data.repository.SportsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

sealed interface ChannelsUiState {
  data object Loading : ChannelsUiState
  data class Success(val channels: List<LiveChannel>) : ChannelsUiState
  data class Error(val message: String) : ChannelsUiState
}

sealed interface MatchesUiState {
  data object Loading : MatchesUiState
  data class Success(val matches: List<MatchFixture>) : MatchesUiState
  data class Error(val message: String) : MatchesUiState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val repository =
    SportsRepository(
      api = JtvControlApi(),
      prefs = StreamPreferencesRepository(application.applicationContext),
    )

  private val _remoteChannels = MutableStateFlow<List<LiveChannel>>(emptyList())
  private val _channelsState = MutableStateFlow<ChannelsUiState>(ChannelsUiState.Loading)
  val channelsState: StateFlow<ChannelsUiState> = _channelsState.asStateFlow()

  private val _matchesState = MutableStateFlow<MatchesUiState>(MatchesUiState.Loading)
  val matchesState: StateFlow<MatchesUiState> = _matchesState.asStateFlow()

  val customChannels: StateFlow<List<LiveChannel>> =
    repository.customChannels.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000),
      initialValue = emptyList(),
    )

  val allChannels: StateFlow<List<LiveChannel>> =
    combine(customChannels, _remoteChannels) { custom, remote -> custom + remote }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList(),
      )

  val favoriteIds: StateFlow<Set<String>> =
    repository.favoriteIds.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000),
      initialValue = emptySet(),
    )

  val recentIds: StateFlow<List<String>> =
    repository.recentIds.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000),
      initialValue = emptyList(),
    )

  val adminToken: StateFlow<String?> =
    repository.adminToken.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000),
      initialValue = null,
    )

  private val _selectedMatchTab = MutableStateFlow(MatchFilterTab.ALL)
  val selectedMatchTab: StateFlow<MatchFilterTab> = _selectedMatchTab.asStateFlow()

  private val _selectedMatchSport = MutableStateFlow("All")
  val selectedMatchSport: StateFlow<String> = _selectedMatchSport.asStateFlow()

  private val _matchSearchQuery = MutableStateFlow("")
  val matchSearchQuery: StateFlow<String> = _matchSearchQuery.asStateFlow()

  private val _selectedChannelCategory = MutableStateFlow("All")
  val selectedChannelCategory: StateFlow<String> = _selectedChannelCategory.asStateFlow()

  private val _channelSearchQuery = MutableStateFlow("")
  val channelSearchQuery: StateFlow<String> = _channelSearchQuery.asStateFlow()

  private val _favoritesOnlyFilter = MutableStateFlow(false)
  val favoritesOnlyFilter: StateFlow<Boolean> = _favoritesOnlyFilter.asStateFlow()

  val channelCategories: StateFlow<List<ChannelCategorySummary>> =
    allChannels
      .map { channels ->
        val grouped = channels.groupBy { it.category.ifBlank { "Other" } }
        grouped.entries.map { (cat, list) ->
          ChannelCategorySummary(
            name = cat,
            count = list.size,
            previewLogoUrl = list.firstOrNull { !it.logoUrl.isNullOrBlank() }?.logoUrl,
          )
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList(),
      )

  val filteredChannels: StateFlow<List<LiveChannel>> =
    combine(
      allChannels,
      _selectedChannelCategory,
      _channelSearchQuery,
      _favoritesOnlyFilter,
      favoriteIds,
    ) { channels, category, query, favOnly, favs ->
      channels.filter { ch ->
        val catOk = category == "All" || ch.category.equals(category, ignoreCase = true)
        val queryOk =
          query.isBlank() ||
            ch.name.contains(query, ignoreCase = true) ||
            ch.category.contains(query, ignoreCase = true)
        val favOk = !favOnly || ch.id in favs
        catOk && queryOk && favOk
      }
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000),
      initialValue = emptyList(),
    )

  // Admin panel state
  private val _adminChannels = MutableStateFlow<List<LiveChannel>>(emptyList())
  val adminChannels: StateFlow<List<LiveChannel>> = _adminChannels.asStateFlow()

  private val _adminStatus = MutableStateFlow<String?>(null)
  val adminStatus: StateFlow<String?> = _adminStatus.asStateFlow()

  private val _adminBusy = MutableStateFlow(false)
  val adminBusy: StateFlow<Boolean> = _adminBusy.asStateFlow()

  // Direct match stream playback selection (for matches with their own streamUrl)
  private val _activePlayable = MutableStateFlow<LiveChannel?>(null)
  val activePlayable: StateFlow<LiveChannel?> = _activePlayable.asStateFlow()

  // Adsterra smart link frequency counter (never pop on every tap)
  private var playerOpenCount = 0

  init {
    refreshAll(showLoadingIfEmpty = true)
    // Auto-sync with Admin Panel API every 30s just like J TV SPORTS web
    viewModelScope.launch {
      while (isActive) {
        delay(30_000)
        refreshAll(showLoadingIfEmpty = false)
      }
    }
  }

  fun refreshAll(showLoadingIfEmpty: Boolean = true) {
    refreshChannels(showLoadingIfEmpty)
    refreshMatches(showLoadingIfEmpty)
  }

  fun refreshChannels(showLoading: Boolean = true) {
    viewModelScope.launch {
      if (showLoading && _remoteChannels.value.isEmpty()) {
        _channelsState.value = ChannelsUiState.Loading
      }
      repository
        .fetchRemoteChannels()
        .onSuccess { list ->
          _remoteChannels.value = list
          _channelsState.value = ChannelsUiState.Success(customChannels.value + list)
        }
        .onFailure { err ->
          if (_remoteChannels.value.isEmpty()) {
            _channelsState.value =
              ChannelsUiState.Error(err.localizedMessage ?: "Failed to load TV channels.")
          }
        }
    }
  }

  fun refreshMatches(showLoading: Boolean = true) {
    viewModelScope.launch {
      val currentOk = _matchesState.value is MatchesUiState.Success
      if (showLoading && !currentOk) {
        _matchesState.value = MatchesUiState.Loading
      }
      repository
        .fetchRemoteMatches()
        .onSuccess { list ->
          _matchesState.value = MatchesUiState.Success(list)
        }
        .onFailure { err ->
          if (!currentOk) {
            _matchesState.value =
              MatchesUiState.Error(err.localizedMessage ?: "Failed to load matches.")
          }
        }
    }
  }

  fun selectMatchTab(tab: MatchFilterTab) {
    _selectedMatchTab.value = tab
  }

  fun selectMatchSport(sport: String) {
    _selectedMatchSport.value = sport
  }

  fun updateMatchSearch(query: String) {
    _matchSearchQuery.value = query
  }

  fun selectChannelCategory(category: String) {
    _selectedChannelCategory.value = category
  }

  fun updateChannelSearch(query: String) {
    _channelSearchQuery.value = query
  }

  fun toggleFavoritesOnlyFilter() {
    _favoritesOnlyFilter.value = !_favoritesOnlyFilter.value
  }

  fun toggleFavorite(channelId: String) {
    viewModelScope.launch { repository.toggleFavorite(channelId) }
  }

  fun setPlayableChannel(channel: LiveChannel) {
    _activePlayable.value = channel
    viewModelScope.launch { repository.recordWatched(channel.id) }
  }

  fun playableFromMatch(match: MatchFixture): LiveChannel? {
    if (match.streamUrl.isNotBlank() && match.streamType != StreamType.NONE) {
      return LiveChannel(
        id = "match_stream_${match.id}",
        channelNumber = "LIVE",
        name = match.title,
        category = match.league,
        logoUrl = match.team1LogoUrl,
        streamType = match.streamType,
        streamUrl = match.streamUrl,
        enabled = true,
      )
    }
    return allChannels.value.firstOrNull {
      it.category.contains(match.sportCategory, ignoreCase = true) ||
        it.name.contains(match.sportCategory, ignoreCase = true)
    } ?: allChannels.value.firstOrNull()
  }

  fun shouldTriggerSmartAdOnOpen(): Boolean {
    playerOpenCount += 1
    return playerOpenCount % 4 == 0
  }

  fun addCustomStream(
    name: String,
    url: String,
    category: String,
    onAdded: (LiveChannel) -> Unit,
  ) {
    viewModelScope.launch {
      val created = repository.addCustomStream(name = name, url = url, category = category)
      onAdded(created)
    }
  }

  fun removeCustomStream(channelId: String) {
    viewModelScope.launch { repository.removeCustomStream(channelId) }
  }

  // Admin Control API actions (syncs directly to same worker backend as website)
  fun adminLogin(password: String) {
    viewModelScope.launch {
      _adminBusy.value = true
      _adminStatus.value = null
      repository
        .adminLogin(password)
        .onSuccess { token ->
          _adminStatus.value = "Logged in to J TV Control API"
          loadAdminChannels(token)
        }
        .onFailure { e -> _adminStatus.value = e.localizedMessage ?: "Login failed" }
      _adminBusy.value = false
    }
  }

  fun adminLogout() {
    viewModelScope.launch {
      repository.adminLogout()
      _adminChannels.value = emptyList()
      _adminStatus.value = null
    }
  }

  fun loadAdminChannels(tokenOverride: String? = adminToken.value) {
    val token = tokenOverride ?: return
    viewModelScope.launch {
      repository
        .adminFetchChannels(token)
        .onSuccess { _adminChannels.value = it }
        .onFailure { _adminStatus.value = it.localizedMessage }
    }
  }

  fun adminSaveChannel(
    existingId: String?,
    name: String,
    category: String,
    logoUrl: String,
    streamType: String,
    streamUrl: String,
    sortOrder: Int,
    enabled: Boolean,
  ) {
    val token = adminToken.value ?: return
    viewModelScope.launch {
      _adminBusy.value = true
      repository
        .adminSaveChannel(
          token = token,
          existingId = existingId,
          name = name,
          category = category,
          logoUrl = logoUrl,
          streamType = streamType,
          streamUrl = streamUrl,
          sortOrder = sortOrder,
          enabled = enabled,
        )
        .onSuccess {
          _adminStatus.value = "Channel saved & synced to Website + App"
          loadAdminChannels(token)
          refreshChannels(showLoading = false)
        }
        .onFailure { _adminStatus.value = it.localizedMessage }
      _adminBusy.value = false
    }
  }

  fun adminDeleteChannel(channelId: String) {
    val token = adminToken.value ?: return
    viewModelScope.launch {
      _adminBusy.value = true
      repository
        .adminDeleteChannel(token, channelId)
        .onSuccess {
          _adminStatus.value = "Channel deleted from Website + App"
          loadAdminChannels(token)
          refreshChannels(showLoading = false)
        }
        .onFailure { _adminStatus.value = it.localizedMessage }
      _adminBusy.value = false
    }
  }

  fun adminAddMatch(
    title: String,
    league: String,
    team1: String,
    team1Logo: String,
    team2: String,
    team2Logo: String,
    matchTime: String,
    status: String,
    streamType: String,
    streamUrl: String,
  ) {
    val token = adminToken.value ?: return
    viewModelScope.launch {
      _adminBusy.value = true
      repository
        .adminAddMatch(
          token = token,
          title = title,
          league = league,
          team1 = team1,
          team1Logo = team1Logo,
          team2 = team2,
          team2Logo = team2Logo,
          matchTime = matchTime,
          status = status,
          streamType = streamType,
          streamUrl = streamUrl,
        )
        .onSuccess {
          _adminStatus.value = "Match added & synced to Website + App"
          refreshMatches(showLoading = false)
        }
        .onFailure { _adminStatus.value = it.localizedMessage }
      _adminBusy.value = false
    }
  }

  fun adminDeleteMatch(matchId: String) {
    val token = adminToken.value ?: return
    viewModelScope.launch {
      _adminBusy.value = true
      repository
        .adminDeleteMatch(token, matchId)
        .onSuccess {
          _adminStatus.value = "Match deleted from Website + App"
          refreshMatches(showLoading = false)
        }
        .onFailure { _adminStatus.value = it.localizedMessage }
      _adminBusy.value = false
    }
  }

  fun clearAdminStatus() {
    _adminStatus.value = null
  }
}

fun MatchFixture.matchesTab(tab: MatchFilterTab): Boolean =
  when (tab) {
    MatchFilterTab.ALL -> true
    MatchFilterTab.LIVE -> status == MatchStatus.LIVE
    MatchFilterTab.UPCOMING -> status == MatchStatus.UPCOMING
    MatchFilterTab.ENDED -> status == MatchStatus.FINISHED
    MatchFilterTab.NEXT_24H -> status == MatchStatus.LIVE || status == MatchStatus.UPCOMING
  }
