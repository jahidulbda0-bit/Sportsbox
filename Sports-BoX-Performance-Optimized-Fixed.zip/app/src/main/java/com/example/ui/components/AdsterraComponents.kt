package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebChromeClient
import android.os.Message
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.AdsterraConfig

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdsterraBannerAd(
  modifier: Modifier = Modifier,
  adKey: String = AdsterraConfig.BANNER_KEY,
  scriptUrl: String = AdsterraConfig.BANNER_SCRIPT_URL,
) {
  val context = LocalContext.current
  val htmlPayload = remember(adKey, scriptUrl) {
    """
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <style>
        html, body {
          margin: 0;
          padding: 0;
          background: #0B192B;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 60px;
          overflow: hidden;
        }
        iframe { max-width: 100% !important; border: 0 !important; }
      </style>
    </head>
    <body>
      <script type="text/javascript">
        atOptions = {
          'key' : '$adKey',
          'format' : 'iframe',
          'height' : 60,
          'width' : 468,
          'params' : {}
        };
      </script>
      <script type="text/javascript" src="$scriptUrl"></script>
    </body>
    </html>
    """.trimIndent()
  }

  Surface(
    modifier = modifier.fillMaxWidth().height(64.dp),
    shape = RoundedCornerShape(10.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Text(
        text = "SPONSORED",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.padding(4.dp),
      )
      AndroidView(
        factory = { ctx ->
          WebView(ctx).apply {
            setBackgroundColor(AndroidColor.TRANSPARENT)
            layoutParams =
              ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
              )
            settings.apply {
              javaScriptEnabled = true
              domStorageEnabled = true
              loadWithOverviewMode = true
              useWideViewPort = true
              mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            }
            webViewClient =
              object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                  view: WebView?,
                  request: WebResourceRequest?,
                ): Boolean {
                  val target = request?.url ?: return false
                  val scheme = target.scheme.orEmpty().lowercase()
                  if (scheme == "http" || scheme == "https") {
                    runCatching {
                      context.startActivity(
                        Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                      )
                    }
                    return true
                  }
                  return false
                }
              }
            loadDataWithBaseURL("https://jtvsports24.blogspot.com/", htmlPayload, "text/html", "UTF-8", null)
          }
        },
        onRelease = { webView ->
          webView.loadUrl("about:blank")
          webView.destroy()
        },
        modifier = Modifier.fillMaxWidth().height(62.dp),
      )
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
fun openAdsterraSmartLink(context: android.content.Context) {
  // This URL is a JavaScript file, not a web page. Load it as a script in WebView
  // instead of trying to open the .js URL in the user's external browser.
  runCatching {
    val host = context as? android.app.Activity ?: return
    val root = host.window?.decorView as? ViewGroup ?: return
    val adView = WebView(context)
    adView.alpha = 0.01f
    adView.visibility = View.VISIBLE
    adView.layoutParams = ViewGroup.LayoutParams(1, 1)
    adView.settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = true
      javaScriptCanOpenWindowsAutomatically = true
      setSupportMultipleWindows(true)
      mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
    }
    adView.webViewClient = object : WebViewClient() {
      override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val target = request?.url ?: return false
        if (target.scheme == "http" || target.scheme == "https") {
          runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
          return true
        }
        return false
      }
    }
    adView.webChromeClient = object : WebChromeClient() {
      override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
        val popup = WebView(context)
        popup.settings.javaScriptEnabled = true
        popup.settings.domStorageEnabled = true
        popup.webViewClient = object : WebViewClient() {
          override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val target = request?.url ?: return false
            if (target.scheme == "http" || target.scheme == "https") {
              runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
              (view?.parent as? ViewGroup)?.removeView(view)
              view?.destroy()
              return true
            }
            return false
          }
        }
        (root as? ViewGroup)?.addView(popup, ViewGroup.LayoutParams(1, 1))
        val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
        transport.webView = popup
        resultMsg.sendToTarget()
        return true
      }
    }
    root.addView(adView, ViewGroup.LayoutParams(1, 1))
    val html = """
      <!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head>
      <body><script data-cfasync="false" src="${AdsterraConfig.POPUNDER_SCRIPT_URL}"></script></body></html>
    """.trimIndent()
    adView.loadDataWithBaseURL("https://capitalhospitals.org/", html, "text/html", "UTF-8", null)
    adView.postDelayed({
      runCatching { root.removeView(adView); adView.stopLoading(); adView.destroy() }
    }, 60_000L)
  }
}
