package com.example.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class StreamType {
  M3U8,
  EMBED,
  YOUTUBE,
  NONE;

  companion object {
    fun detect(rawType: String?, url: String): StreamType {
      val t = rawType.orEmpty().trim().lowercase()
      val u = url.trim().lowercase()
      return when {
        u.isBlank() -> NONE
        t == "m3u8" || t == "hls" || u.contains(".m3u8") || u.contains(".mp4") || u.contains(".mpd") -> M3U8
        t == "youtube" || u.contains("youtube.com") || u.contains("youtu.be") -> YOUTUBE
        t == "embed" -> EMBED
        t == "none" -> NONE
        else -> EMBED
      }
    }
  }
}

@Serializable
enum class ChannelArtwork {
  STADIUM_HERO,
  CRICKET_ARENA,
  FOOTBALL_PITCH,
  COURT_ARENA,
}

@Serializable
data class LiveChannel(
  val id: String,
  val channelNumber: String,
  val name: String,
  val category: String,
  val logoUrl: String? = null,
  val streamType: StreamType = StreamType.M3U8,
  val streamUrl: String,
  val sortOrder: Int = 0,
  val enabled: Boolean = true,
  val isCustom: Boolean = false,
  val artwork: ChannelArtwork = ChannelArtwork.STADIUM_HERO,
)

enum class MatchFilterTab(val label: String) {
  NEXT_24H("Next 24h"),
  LIVE("Live"),
  UPCOMING("Upcoming"),
  ENDED("End"),
  ALL("All"),
}

enum class MatchStatus {
  LIVE,
  UPCOMING,
  FINISHED,
}

data class MatchFixture(
  val id: String,
  val title: String,
  val league: String,
  val sportCategory: String,
  val team1: String,
  val team2: String,
  val team1LogoUrl: String?,
  val team2LogoUrl: String?,
  val matchTime: String,
  val status: MatchStatus,
  val streamType: StreamType,
  val streamUrl: String,
  val isHot: Boolean = false,
)

data class ChannelCategorySummary(
  val name: String,
  val count: Int,
  val previewLogoUrl: String?,
)

object AdsterraConfig {
  const val BANNER_KEY = "6b4bf323ff09a1edee5c24cae44a230c"
  const val BANNER_SCRIPT_URL = "https://czernik.org/22/6b4bf323ff09a1edee5c24cae44a230c"
  const val POPUNDER_SCRIPT_URL = "https://capitalhospitals.org/1/3b90fa8b9d8634b18a93066d2e7ee92f"
}
