package com.example.data.remote

import com.example.data.model.ChannelArtwork
import com.example.data.model.LiveChannel
import com.example.data.model.MatchFixture
import com.example.data.model.MatchStatus
import com.example.data.model.StreamType
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class JtvControlApi {

  companion object {
    const val BASE_URL = "https://j-tv-control-api.jahidul-bda0.workers.dev"

    private val countryFlagCodes =
      mapOf(
        "bangladesh" to "bd",
        "bangladesh-w" to "bd",
        "india" to "in",
        "india-w" to "in",
        "pakistan" to "pk",
        "pakistan-w" to "pk",
        "nepal" to "np",
        "australia" to "au",
        "australia-w" to "au",
        "england" to "gb-eng",
        "england-w" to "gb-eng",
        "new zealand" to "nz",
        "south africa" to "za",
        "sri lanka" to "lk",
        "afghanistan" to "af",
        "ireland" to "ie",
        "ireland-w" to "ie",
        "usa" to "us",
        "united states" to "us",
        "uae" to "ae",
        "oman" to "om",
        "qatar" to "qa",
        "saudi arabia" to "sa",
        "scotland" to "gb-sct",
        "wales" to "gb-wls",
        "poland" to "pl",
        "ukraine" to "ua",
        "brazil" to "br",
        "argentina" to "ar",
        "france" to "fr",
        "spain" to "es",
        "germany" to "de",
        "portugal" to "pt",
        "italy" to "it",
        "netherlands" to "nl",
      )

    fun resolveFlagUrl(teamName: String): String? {
      val code = countryFlagCodes[teamName.trim().lowercase()] ?: return null
      return "https://flagcdn.com/w80/$code.png"
    }

    fun buildYoutubeEmbedUrl(rawUrl: String): String {
      return runCatching {
        val uri = android.net.Uri.parse(rawUrl)
        val host = uri.host.orEmpty().lowercase()
        val videoId =
          when {
            host.contains("youtu.be") -> uri.pathSegments.firstOrNull().orEmpty()
            !uri.getQueryParameter("v").isNullOrBlank() -> uri.getQueryParameter("v").orEmpty()
            uri.path.orEmpty().contains("/embed/") ->
              uri.path.orEmpty().substringAfter("/embed/").substringBefore("/")
            uri.path.orEmpty().contains("/live/") ->
              uri.path.orEmpty().substringAfter("/live/").substringBefore("/")
            else -> ""
          }
        if (videoId.isNotBlank()) {
          "https://www.youtube.com/embed/${android.net.Uri.encode(videoId)}?autoplay=1&playsinline=1&rel=0"
        } else {
          rawUrl
        }
      }.getOrDefault(rawUrl)
    }
  }

  private val json = Json { ignoreUnknownKeys = true }

  private val client: OkHttpClient =
    OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(20, TimeUnit.SECONDS)
      .addInterceptor(
        HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC },
      )
      .build()

  suspend fun fetchChannels(): Result<List<LiveChannel>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val req =
          Request.Builder()
            .url("$BASE_URL/api/channels")
            .header("Cache-Control", "no-cache")
            .get()
            .build()
        val body =
          client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("HTTP ${resp.code}")
            resp.body?.string().orEmpty()
          }
        val root = json.parseToJsonElement(body)
        if (root is JsonObject && root["success"]?.jsonPrimitive?.booleanOrNull == false) {
          error(root.str("message") ?: root.str("error") ?: "API error")
        }
        val arr = extractArray(root, listOf("channels", "items", "results"))
        arr
          .mapIndexedNotNull { idx, elem -> parseChannel(elem as? JsonObject, idx) }
          .filter { it.enabled && it.streamUrl.isNotBlank() }
          .sortedBy { it.sortOrder }
      }
    }

  suspend fun fetchMatches(): Result<List<MatchFixture>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val req =
          Request.Builder()
            .url("$BASE_URL/api/matches")
            .header("Cache-Control", "no-cache")
            .get()
            .build()
        val body =
          client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("HTTP ${resp.code}")
            resp.body?.string().orEmpty()
          }
        val root = json.parseToJsonElement(body)
        if (root is JsonObject && root["success"]?.jsonPrimitive?.booleanOrNull == false) {
          error(root.str("message") ?: root.str("error") ?: "API error")
        }
        val arr = extractArray(root, listOf("matches", "items", "results"))
        arr.mapIndexedNotNull { idx, elem -> parseMatch(elem as? JsonObject, idx) }
      }
    }

  suspend fun adminLogin(password: String): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val payload = """{"password":${JsonPrimitive(password)}}"""
        val req =
          Request.Builder()
            .url("$BASE_URL/api/login")
            .post(payload.toRequestBody("application/json".toMediaType()))
            .build()
        val body =
          client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            val obj = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull()
            if (!resp.isSuccessful) {
              error(obj?.str("error") ?: "Login failed (HTTP ${resp.code})")
            }
            raw
          }
        val root = json.parseToJsonElement(body).jsonObject
        root.str("token") ?: error("Token missing from login response")
      }
    }

  suspend fun adminFetchChannels(token: String): Result<List<LiveChannel>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val req =
          Request.Builder()
            .url("$BASE_URL/api/admin/channels")
            .header("Authorization", "Bearer $token")
            .get()
            .build()
        val body =
          client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error(parseError(raw, resp.code))
            raw
          }
        val root = json.parseToJsonElement(body)
        val arr = extractArray(root, listOf("channels", "items", "results"))
        arr.mapIndexedNotNull { idx, elem -> parseChannel(elem as? JsonObject, idx) }
      }
    }

  suspend fun adminSaveChannel(
    token: String,
    existingId: String?,
    name: String,
    category: String,
    logoUrl: String,
    streamType: String,
    streamUrl: String,
    sortOrder: Int,
    enabled: Boolean,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val bodyJson =
          buildString {
            append("{")
            append("\"name\":${JsonPrimitive(name)},")
            append("\"category\":${JsonPrimitive(category)},")
            append("\"logo\":${JsonPrimitive(logoUrl)},")
            append("\"stream_type\":${JsonPrimitive(streamType)},")
            append("\"stream_url\":${JsonPrimitive(streamUrl)},")
            append("\"sort_order\":$sortOrder,")
            append("\"enabled\":$enabled")
            append("}")
          }
        val reqBuilder =
          Request.Builder()
            .url(
              if (existingId.isNullOrBlank()) "$BASE_URL/api/channels"
              else "$BASE_URL/api/channels/$existingId",
            )
            .header("Authorization", "Bearer $token")
        val mediaBody = bodyJson.toRequestBody("application/json".toMediaType())
        if (existingId.isNullOrBlank()) reqBuilder.post(mediaBody) else reqBuilder.put(mediaBody)

        client.newCall(reqBuilder.build()).execute().use { resp ->
          val raw = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error(parseError(raw, resp.code))
        }
      }
    }

  suspend fun adminDeleteChannel(token: String, channelId: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val req =
          Request.Builder()
            .url("$BASE_URL/api/channels/$channelId")
            .header("Authorization", "Bearer $token")
            .delete()
            .build()
        client.newCall(req).execute().use { resp ->
          val raw = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error(parseError(raw, resp.code))
        }
      }
    }

  suspend fun adminAddMatch(
    token: String,
    title: String,
    league: String,
    team1: String,
    team1Logo: String,
    team2: String,
    team2Logo: String,
    matchTime: String,
    status: String,
    streamType: String,
    streamUrl: String,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val bodyJson =
          buildString {
            append("{")
            append("\"title\":${JsonPrimitive(title)},")
            append("\"league\":${JsonPrimitive(league)},")
            append("\"team1\":${JsonPrimitive(team1)},")
            append("\"team1_logo\":${JsonPrimitive(team1Logo)},")
            append("\"team2\":${JsonPrimitive(team2)},")
            append("\"team2_logo\":${JsonPrimitive(team2Logo)},")
            append("\"match_time\":${JsonPrimitive(matchTime)},")
            append("\"status\":${JsonPrimitive(status)},")
            append("\"stream_type\":${JsonPrimitive(streamType)},")
            append("\"stream_url\":${JsonPrimitive(streamUrl)}")
            append("}")
          }
        val req =
          Request.Builder()
            .url("$BASE_URL/api/matches")
            .header("Authorization", "Bearer $token")
            .post(bodyJson.toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { resp ->
          val raw = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error(parseError(raw, resp.code))
        }
      }
    }

  suspend fun adminDeleteMatch(token: String, matchId: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val req =
          Request.Builder()
            .url("$BASE_URL/api/matches/$matchId")
            .header("Authorization", "Bearer $token")
            .delete()
            .build()
        client.newCall(req).execute().use { resp ->
          val raw = resp.body?.string().orEmpty()
          if (!resp.isSuccessful) error(parseError(raw, resp.code))
        }
      }
    }

  private fun parseError(raw: String, code: Int): String {
    val obj = runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull()
    return obj?.str("error") ?: obj?.str("message") ?: "Request failed (HTTP $code)"
  }

  private fun extractArray(root: JsonElement, keys: List<String>): List<JsonElement> {
    if (root is JsonArray) return root
    if (root !is JsonObject) return emptyList()
    for (k in keys) {
      val child = root[k]
      if (child is JsonArray) return child
    }
    val data = root["data"]
    if (data is JsonArray) return data
    if (data is JsonObject) {
      for (k in keys) {
        val child = data[k]
        if (child is JsonArray) return child
      }
    }
    return emptyList()
  }

  private fun parseChannel(obj: JsonObject?, index: Int): LiveChannel? {
    if (obj == null) return null
    val name =
      obj.firstStr("name", "title", "channel_name", "match_name") ?: return null
    val url =
      obj.firstStr("stream_url", "url", "streamUrl", "link", "source", "embed_url")
        .orEmpty()
    val logo =
      obj.firstStr("logo", "logo_url", "logoUrl", "tvg_logo", "tvgLogo", "image", "icon", "thumbnail")
    val category =
      obj.firstStr("category", "group", "group_title", "genre") ?: "Sports"
    val rawType = obj.firstStr("stream_type", "type", "source_type")
    val streamType = StreamType.detect(rawType, url)
    val id = obj.firstStr("id") ?: "ch_${index}_${name.hashCode()}"
    val sortOrder = obj["sort_order"]?.jsonPrimitive?.intOrNull ?: index
    val enabled =
      obj["enabled"]?.jsonPrimitive?.let { p ->
        p.booleanOrNull ?: (p.content != "0" && !p.content.equals("false", ignoreCase = true))
      } ?: true

    val artwork =
      when {
        category.contains("cricket", ignoreCase = true) -> ChannelArtwork.CRICKET_ARENA
        category.contains("football", ignoreCase = true) -> ChannelArtwork.FOOTBALL_PITCH
        category.contains("basket", ignoreCase = true) -> ChannelArtwork.COURT_ARENA
        else -> ChannelArtwork.STADIUM_HERO
      }

    return LiveChannel(
      id = id,
      channelNumber = (200 + index + 1).toString(),
      name = name,
      category = category,
      logoUrl = logo?.takeIf { it.isNotBlank() },
      streamType = streamType,
      streamUrl = url,
      sortOrder = sortOrder,
      enabled = enabled,
      isCustom = false,
      artwork = artwork,
    )
  }

  private fun parseMatch(obj: JsonObject?, index: Int): MatchFixture? {
    if (obj == null) return null
    val team1 = obj.firstStr("team1", "home_team", "team_a") ?: "Team A"
    val team2 = obj.firstStr("team2", "away_team", "team_b") ?: "Team B"
    val title = obj.firstStr("title", "match_name") ?: "$team1 vs $team2"
    val league = obj.firstStr("league", "tournament", "category") ?: "Sports"
    val logo1 =
      obj.firstStr("team1_logo", "home_team_logo", "team_a_logo")?.takeIf { it.isNotBlank() }
        ?: resolveFlagUrl(team1)
    val logo2 =
      obj.firstStr("team2_logo", "away_team_logo", "team_b_logo")?.takeIf { it.isNotBlank() }
        ?: resolveFlagUrl(team2)
    val time = obj.firstStr("match_time", "time")?.takeIf { it.isNotBlank() } ?: "LIVE"
    val rawStatus = obj.firstStr("status").orEmpty().lowercase()
    val status =
      when {
        rawStatus.contains("live") || rawStatus.contains("play") -> MatchStatus.LIVE
        rawStatus.contains("finish") || rawStatus == "end" || rawStatus == "ended" || rawStatus == "ft" ->
          MatchStatus.FINISHED
        else -> MatchStatus.UPCOMING
      }
    val url =
      obj.firstStr("stream_url", "url", "streamUrl", "link", "source", "embed_url").orEmpty()
    val rawType = obj.firstStr("stream_type", "type", "source_type")
    val streamType = StreamType.detect(rawType, url)
    val id = obj.firstStr("id") ?: "match_${index}_${title.hashCode()}"
    val sportCat =
      when {
        league.contains("cricket", ignoreCase = true) ||
          league.contains("ipl", ignoreCase = true) ||
          league.contains("t20", ignoreCase = true) ||
          league.contains("t10", ignoreCase = true) ||
          league.contains("asia cup", ignoreCase = true) ||
          league.contains("rising stars", ignoreCase = true) ||
          league.contains("tour of", ignoreCase = true) ||
          league.contains("odi", ignoreCase = true) ||
          league.contains("psl", ignoreCase = true) ||
          league.contains("bpl", ignoreCase = true) ||
          league.contains("bbl", ignoreCase = true) ||
          league.contains("cpl", ignoreCase = true) ||
          league.contains("sa20", ignoreCase = true) ||
          league.contains("hundred", ignoreCase = true) -> "Cricket"
        league.contains("moto", ignoreCase = true) ||
          league.contains("f1", ignoreCase = true) ||
          league.contains("formula", ignoreCase = true) -> "Motorsport"
        league.contains("nba", ignoreCase = true) ||
          league.contains("basket", ignoreCase = true) -> "Basketball"
        else -> "Football"
      }

    return MatchFixture(
      id = id,
      title = title,
      league = league,
      sportCategory = sportCat,
      team1 = team1,
      team2 = team2,
      team1LogoUrl = logo1,
      team2LogoUrl = logo2,
      matchTime = time,
      status = status,
      streamType = streamType,
      streamUrl = url,
      isHot = status == MatchStatus.LIVE,
    )
  }

  private fun JsonObject.str(key: String): String? {
    val prim = this[key] as? JsonPrimitive ?: return null
    val s = prim.content
    return s.takeIf { it.isNotBlank() && it != "null" }
  }

  private fun JsonObject.firstStr(vararg keys: String): String? {
    for (k in keys) {
      val v = str(k)
      if (v != null) return v
    }
    return null
  }
}
