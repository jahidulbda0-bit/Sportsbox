package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ChannelCategorySummary
import com.example.data.model.LiveChannel
import com.example.ui.components.AdsterraBannerAd
import com.example.ui.components.ChannelCategoryCard
import com.example.ui.components.TvGridChannelCard
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.LiveCrimson
import com.example.ui.viewmodel.ChannelsUiState

@Composable
fun ChannelsScreen(
  channelsState: ChannelsUiState,
  allChannels: List<LiveChannel>,
  filteredChannels: List<LiveChannel>,
  categories: List<ChannelCategorySummary>,
  favoriteIds: Set<String>,
  selectedCategory: String,
  searchQuery: String,
  favoritesOnly: Boolean,
  onSelectCategory: (String) -> Unit,
  onSearchQueryChanged: (String) -> Unit,
  onToggleFavoritesOnly: () -> Unit,
  onChannelClick: (LiveChannel) -> Unit,
  onToggleFavorite: (String) -> Unit,
  onRetry: () -> Unit,
  modifier: Modifier = Modifier,
) {
  // Two modes matching Screenshots 8 & 9:
  // 1) Category Cards overview (2-col)
  // 2) Channel Grid view (3-col mobile, 4-5 tablet)
  var showCategoryOverview by remember { mutableStateOf(false) }

  BackHandler(enabled = !showCategoryOverview && selectedCategory != "All") {
    onSelectCategory("All")
    showCategoryOverview = true
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val tvColumns =
      when {
        maxWidth >= 900.dp -> 5
        maxWidth >= 600.dp -> 4
        else -> 3
      }
    val categoryColumns = if (maxWidth >= 700.dp) 3 else 2

    when (channelsState) {
      is ChannelsUiState.Loading -> {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            CircularProgressIndicator(color = ElectricEmerald)
            Text(
              text = "Syncing Live TV Channels…",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }

      is ChannelsUiState.Error -> {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
          Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.CloudOff,
                contentDescription = null,
                tint = LiveCrimson,
                modifier = Modifier.size(40.dp),
              )
              Text(
                text = "TV Channels Unavailable",
                style = MaterialTheme.typography.titleMedium,
              )
              Text(
                text = channelsState.message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
              )
              Button(onClick = onRetry) {
                Text(stringResource(R.string.retry))
              }
            }
          }
        }
      }

      is ChannelsUiState.Success -> {
        if (showCategoryOverview) {
          LazyVerticalGrid(
            columns = GridCells.Fixed(categoryColumns),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 96.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "TV CATEGORIES",
                  style = MaterialTheme.typography.headlineSmall,
                )
                Surface(
                  onClick = { showCategoryOverview = false },
                  shape = RoundedCornerShape(10.dp),
                  color = MaterialTheme.colorScheme.primaryContainer,
                  modifier = Modifier.testTag("toggle_all_channels_view"),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                  ) {
                    Icon(
                      imageVector = Icons.Filled.GridView,
                      contentDescription = null,
                      tint = ElectricEmerald,
                      modifier = Modifier.size(16.dp),
                    )
                    Text(
                      text = "All (${allChannels.size})",
                      style = MaterialTheme.typography.labelLarge,
                      color = ElectricEmerald,
                    )
                  }
                }
              }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
              AdsterraBannerAd()
            }

            items(items = categories, key = { it.name }) { cat ->
              ChannelCategoryCard(
                summary = cat,
                onClick = {
                  onSelectCategory(cat.name)
                  showCategoryOverview = false
                },
              )
            }
          }
        } else {
          LazyVerticalGrid(
            columns = GridCells.Fixed(tvColumns),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
          ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
              Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    if (selectedCategory != "All") {
                      IconButton(
                        onClick = {
                          onSelectCategory("All")
                          showCategoryOverview = true
                        },
                        modifier = Modifier.minimumInteractiveComponentSize(),
                      ) {
                        Icon(
                          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                          contentDescription = stringResource(R.string.back),
                        )
                      }
                    }
                    Column {
                      Text(
                        text =
                          if (selectedCategory == "All") "ALL TV CHANNELS"
                          else selectedCategory.uppercase(),
                        style = MaterialTheme.typography.headlineSmall,
                      )
                      Text(
                        text = "${filteredChannels.size} Channels",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricEmerald,
                      )
                    }
                  }

                  Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                      onClick = onToggleFavoritesOnly,
                      modifier = Modifier.minimumInteractiveComponentSize().testTag("fav_filter_button"),
                    ) {
                      Icon(
                        imageVector =
                          if (favoritesOnly) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = stringResource(R.string.favorite_toggle),
                        tint = if (favoritesOnly) LiveCrimson else MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                    }
                    IconButton(
                      onClick = { showCategoryOverview = true },
                      modifier = Modifier.minimumInteractiveComponentSize().testTag("category_grid_button"),
                    ) {
                      Icon(
                        imageVector = Icons.Filled.ViewModule,
                        contentDescription = "Categories view",
                        tint = ElectricEmerald,
                      )
                    }
                  }
                }

                OutlinedTextField(
                  value = searchQuery,
                  onValueChange = onSearchQueryChanged,
                  modifier = Modifier.fillMaxWidth().testTag("channel_search_input"),
                  placeholder = { Text(stringResource(R.string.search_channels_hint)) },
                  leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                  trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                      IconButton(onClick = { onSearchQueryChanged("") }) {
                        Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                      }
                    }
                  },
                  singleLine = true,
                  shape = RoundedCornerShape(14.dp),
                  colors =
                    OutlinedTextFieldDefaults.colors(
                      focusedContainerColor = MaterialTheme.colorScheme.surface,
                      unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    ),
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  item {
                    FilterChip(
                      selected = selectedCategory == "All",
                      onClick = { onSelectCategory("All") },
                      label = { Text("All (${allChannels.size})") },
                      colors =
                        FilterChipDefaults.filterChipColors(
                          selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                          selectedLabelColor = ElectricEmerald,
                        ),
                    )
                  }
                  items(categories, key = { "chip_${it.name}" }) { cat ->
                    FilterChip(
                      selected = selectedCategory.equals(cat.name, ignoreCase = true),
                      onClick = { onSelectCategory(cat.name) },
                      label = { Text("${cat.name} (${cat.count})") },
                      colors =
                        FilterChipDefaults.filterChipColors(
                          selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                          selectedLabelColor = ElectricEmerald,
                        ),
                    )
                  }
                }

                AdsterraBannerAd()
              }
            }

            if (filteredChannels.isEmpty()) {
              item(span = { GridItemSpan(maxLineSpan) }) {
                Surface(
                  modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                  shape = MaterialTheme.shapes.large,
                  color = MaterialTheme.colorScheme.surface,
                  border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                  Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                  ) {
                    Icon(
                      imageVector = Icons.Filled.LiveTv,
                      contentDescription = null,
                      tint = ElectricEmerald,
                      modifier = Modifier.size(38.dp),
                    )
                    Text(
                      text = stringResource(R.string.no_channels_found),
                      style = MaterialTheme.typography.titleMedium,
                      textAlign = TextAlign.Center,
                    )
                    Text(
                      text = stringResource(R.string.no_channels_tip),
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      textAlign = TextAlign.Center,
                    )
                  }
                }
              }
            } else {
              items(items = filteredChannels, key = { it.id }) { channel ->
                TvGridChannelCard(
                  channel = channel,
                  isFavorite = channel.id in favoriteIds,
                  onPlayClick = { onChannelClick(channel) },
                  onFavoriteClick = { onToggleFavorite(channel.id) },
                )
              }
            }
          }
        }
      }
    }
  }
}
