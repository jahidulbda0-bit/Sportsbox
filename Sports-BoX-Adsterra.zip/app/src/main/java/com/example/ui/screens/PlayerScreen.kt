package com.example.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.data.model.LiveChannel
import com.example.data.model.StreamType
import com.example.data.remote.JtvControlApi
import com.example.ui.components.AdsterraBannerAd
import com.example.ui.components.LivePulseBadge
import com.example.ui.components.TvGridChannelCard
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.LiveCrimson
import com.example.ui.theme.StadiumObsidian
import kotlinx.coroutines.delay

private data class TrackOptionItem(
  val label: String,
  val group: TrackGroup?,
  val trackIndex: Int,
  val selected: Boolean,
)

@SuppressLint("SetJavaScriptEnabled")
@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
  channel: LiveChannel,
  allChannels: List<LiveChannel>,
  favoriteIds: Set<String>,
  onBackClick: () -> Unit,
  onSelectChannel: (LiveChannel) -> Unit,
  onToggleFavorite: (String) -> Unit,
) {
  val context = LocalContext.current
  val activity = remember(context) { context.findActivity() }
  val lifecycleOwner = LocalLifecycleOwner.current

  val isNativeExoStream =
    channel.streamType == StreamType.M3U8 ||
      channel.streamUrl.contains(".m3u8", ignoreCase = true) ||
      channel.streamUrl.contains(".mp4", ignoreCase = true) ||
      channel.streamUrl.contains(".mpd", ignoreCase = true)

  var isFullscreen by remember { mutableStateOf(false) }
  var isControlsLocked by remember { mutableStateOf(false) }
  var showControls by remember { mutableStateOf(true) }
  var isPlaying by remember { mutableStateOf(true) }
  var isBuffering by remember { mutableStateOf(isNativeExoStream) }
  var isMuted by remember { mutableStateOf(false) }
  var resolutionText by remember { mutableStateOf(channel.streamType.name) }
  var playbackError by remember { mutableStateOf<String?>(null) }
  var resizeModeIndex by remember { mutableIntStateOf(0) }
  var retryTrigger by remember { mutableIntStateOf(0) }
  var showQualityDialog by remember { mutableStateOf(false) }
  var currentTracks by remember { mutableStateOf(Tracks.EMPTY) }

  val resizeModes = remember {
    listOf(
      AspectRatioFrameLayout.RESIZE_MODE_FIT to "FIT",
      AspectRatioFrameLayout.RESIZE_MODE_FILL to "FILL",
      AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "ZOOM",
    )
  }

  val exoPlayer = remember {
    ExoPlayer.Builder(context).build().apply {
      playWhenReady = true
    }
  }

  // Keep screen awake during live streaming
  DisposableEffect(activity) {
    activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    onDispose {
      activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
  }

  // Fullscreen orientation & immersive system bars
  DisposableEffect(isFullscreen, activity) {
    if (activity != null) {
      val insetsController =
        WindowCompat.getInsetsController(activity.window, activity.window.decorView)
      if (isFullscreen) {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        insetsController.systemBarsBehavior =
          WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
      } else {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        insetsController.show(WindowInsetsCompat.Type.systemBars())
      }
    }
    onDispose {
      if (activity != null && isFullscreen) {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val insetsController =
          WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
      }
    }
  }

  BackHandler {
    if (isFullscreen) {
      isFullscreen = false
    } else {
      onBackClick()
    }
  }

  // Prepare stream into ExoPlayer if native HLS/MP4/DASH
  LaunchedEffect(channel.id, channel.streamUrl, isNativeExoStream, retryTrigger) {
    playbackError = null
    if (isNativeExoStream) {
      isBuffering = true
      resolutionText = "HLS"
      exoPlayer.setMediaItem(MediaItem.fromUri(channel.streamUrl))
      exoPlayer.prepare()
      exoPlayer.playWhenReady = true
    } else {
      exoPlayer.stop()
      isBuffering = false
      resolutionText = channel.streamType.name
    }
  }

  LaunchedEffect(showControls, isPlaying) {
    if (showControls && isPlaying && playbackError == null && !showQualityDialog) {
      delay(3500)
      showControls = false
    }
  }

  DisposableEffect(exoPlayer, lifecycleOwner) {
    val listener =
      object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
          if (isNativeExoStream) {
            isBuffering = playbackState == Player.STATE_BUFFERING
            if (playbackState == Player.STATE_READY) {
              playbackError = null
            }
          }
        }

        override fun onIsPlayingChanged(playing: Boolean) {
          isPlaying = playing
        }

        override fun onTracksChanged(tracks: Tracks) {
          currentTracks = tracks
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
          if (videoSize.width > 0 && videoSize.height > 0) {
            resolutionText = "${videoSize.width}×${videoSize.height}"
          }
        }

        override fun onPlayerError(error: PlaybackException) {
          if (isNativeExoStream) {
            isBuffering = false
            playbackError = error.localizedMessage ?: "Unable to connect to live stream."
          }
        }
      }
    exoPlayer.addListener(listener)

    val lifecycleObserver = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE -> exoPlayer.pause()
        Lifecycle.Event.ON_RESUME -> if (isNativeExoStream && isPlaying) exoPlayer.play()
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(lifecycleObserver)

    onDispose {
      lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
      exoPlayer.removeListener(listener)
      exoPlayer.release()
    }
  }

  val quickSwitchChannels = remember(channel.id, allChannels) {
    allChannels.take(10)
  }

  val relatedChannels = remember(channel.id, allChannels) {
    allChannels.filterNot { it.id == channel.id }
  }

  Column(
    modifier = Modifier.fillMaxSize().background(StadiumObsidian),
  ) {
    // Player Viewport
    Box(
      modifier =
        Modifier
          .then(
            if (isFullscreen) Modifier.fillMaxSize()
            else Modifier.fillMaxWidth().statusBarsPadding().aspectRatio(16f / 9f),
          )
          .background(Color.Black)
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
          ) { showControls = !showControls },
    ) {
      if (isNativeExoStream) {
        AndroidView(
          factory = { ctx ->
            PlayerView(ctx).apply {
              useController = false
              player = exoPlayer
              layoutParams =
                ViewGroup.LayoutParams(
                  ViewGroup.LayoutParams.MATCH_PARENT,
                  ViewGroup.LayoutParams.MATCH_PARENT,
                )
            }
          },
          update = { view ->
            view.resizeMode = resizeModes[resizeModeIndex].first
          },
          modifier = Modifier.fillMaxSize(),
        )
      } else {
        val embedUrl =
          remember(channel.streamUrl, channel.streamType) {
            if (channel.streamType == StreamType.YOUTUBE ||
              channel.streamUrl.contains("youtube.com") ||
              channel.streamUrl.contains("youtu.be")
            ) {
              JtvControlApi.buildYoutubeEmbedUrl(channel.streamUrl)
            } else {
              channel.streamUrl
            }
          }
        AndroidView(
          factory = { ctx ->
            WebView(ctx).apply {
              setBackgroundColor(AndroidColor.BLACK)
              layoutParams =
                ViewGroup.LayoutParams(
                  ViewGroup.LayoutParams.MATCH_PARENT,
                  ViewGroup.LayoutParams.MATCH_PARENT,
                )
              settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
              }
              webChromeClient = WebChromeClient()
              webViewClient = WebViewClient()
              loadUrl(embedUrl)
            }
          },
          update = { webView ->
            if (webView.url != embedUrl) {
              webView.loadUrl(embedUrl)
            }
          },
          onRelease = { webView ->
            webView.loadUrl("about:blank")
            webView.destroy()
          },
          modifier = Modifier.fillMaxSize(),
        )
      }

      if (isBuffering && playbackError == null) {
        CircularProgressIndicator(
          color = ElectricEmerald,
          modifier = Modifier.align(Alignment.Center).size(42.dp),
        )
      }

      if (playbackError != null) {
        Box(
          modifier = Modifier.fillMaxSize().background(StadiumObsidian.copy(alpha = 0.90f)).padding(20.dp),
          contentAlignment = Alignment.Center,
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.ErrorOutline,
              contentDescription = null,
              tint = LiveCrimson,
              modifier = Modifier.size(34.dp),
            )
            Text(
              text = stringResource(R.string.stream_error_title),
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
            )
            Text(
              text = playbackError ?: stringResource(R.string.stream_error_hint),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
            Button(
              onClick = { retryTrigger++ },
              modifier = Modifier.testTag("retry_stream_button"),
            ) {
              Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(stringResource(R.string.retry))
            }
          }
        }
      }

      androidx.compose.animation.AnimatedVisibility(
        visible = showControls && playbackError == null,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = Modifier.fillMaxSize(),
      ) {
        Box(
          modifier =
            Modifier.fillMaxSize()
              .background(
                Brush.verticalGradient(
                  listOf(
                    Color.Black.copy(alpha = 0.72f),
                    Color.Black.copy(alpha = 0.14f),
                    Color.Black.copy(alpha = 0.80f),
                  ),
                ),
              )
              .padding(horizontal = 8.dp, vertical = 6.dp),
        ) {
          if (isControlsLocked) {
            IconButton(
              onClick = { isControlsLocked = false },
              modifier =
                Modifier.align(Alignment.TopEnd)
                  .minimumInteractiveComponentSize()
                  .testTag("unlock_controls_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = stringResource(R.string.lock_controls),
                tint = ElectricEmerald,
              )
            }
          } else {
            // Top HUD bar (matching Screenshots 3 & 5)
            Row(
              modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
              ) {
                IconButton(
                  onClick = { if (isFullscreen) isFullscreen = false else onBackClick() },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("player_back_button"),
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.back),
                    tint = Color.White,
                  )
                }
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = channel.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    text = "${channel.category} • $resolutionText",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricEmerald,
                  )
                }
              }

              Row(verticalAlignment = Alignment.CenterVertically) {
                if (isNativeExoStream) {
                  IconButton(
                    onClick = { showQualityDialog = true },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("quality_settings_button"),
                  ) {
                    Icon(
                      imageVector = Icons.Filled.Settings,
                      contentDescription = stringResource(R.string.quality_settings),
                      tint = Color.White,
                    )
                  }
                }
                IconButton(
                  onClick = { isControlsLocked = true },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(
                    imageVector = Icons.Filled.LockOpen,
                    contentDescription = stringResource(R.string.lock_controls),
                    tint = Color.White,
                  )
                }
              }
            }

            // Center transport controls (for native ExoPlayer)
            if (isNativeExoStream) {
              Row(
                modifier = Modifier.align(Alignment.Center),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(22.dp),
              ) {
                IconButton(
                  onClick = {
                    val target = (exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)
                    exoPlayer.seekTo(target)
                  },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(
                    imageVector = Icons.Filled.Replay10,
                    contentDescription = "Rewind 10s",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp),
                  )
                }

                Surface(
                  onClick = {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                  },
                  shape = CircleShape,
                  color = Color.White,
                  modifier = Modifier.size(52.dp).testTag("player_play_pause_button"),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                      contentDescription = stringResource(R.string.play_pause),
                      tint = StadiumObsidian,
                      modifier = Modifier.size(30.dp),
                    )
                  }
                }

                IconButton(
                  onClick = { exoPlayer.seekToDefaultPosition() },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(
                    imageVector = Icons.Filled.FastForward,
                    contentDescription = stringResource(R.string.jump_to_live),
                    tint = Color.White,
                    modifier = Modifier.size(30.dp),
                  )
                }
              }
            }

            // Bottom HUD bar
            Row(
              modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                if (isNativeExoStream) {
                  IconButton(
                    onClick = {
                      isMuted = !isMuted
                      exoPlayer.volume = if (isMuted) 0f else 1f
                    },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("player_mute_button"),
                  ) {
                    Icon(
                      imageVector =
                        if (isMuted) Icons.AutoMirrored.Filled.VolumeOff
                        else Icons.AutoMirrored.Filled.VolumeUp,
                      contentDescription = stringResource(R.string.toggle_mute),
                      tint = Color.White,
                    )
                  }
                }
                LivePulseBadge(isLive = true)
              }

              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                if (isNativeExoStream) {
                  Surface(
                    onClick = { resizeModeIndex = (resizeModeIndex + 1) % resizeModes.size },
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White.copy(alpha = 0.16f),
                    modifier = Modifier.testTag("aspect_ratio_button"),
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                      Icon(
                        imageVector = Icons.Filled.AspectRatio,
                        contentDescription = stringResource(R.string.aspect_mode),
                        tint = Color.White,
                        modifier = Modifier.size(16.dp),
                      )
                      Text(
                        text = resizeModes[resizeModeIndex].second,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                      )
                    }
                  }
                }

                IconButton(
                  onClick = { isFullscreen = !isFullscreen },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("player_fullscreen_button"),
                ) {
                  Icon(
                    imageVector =
                      if (isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                    contentDescription = stringResource(R.string.toggle_fullscreen),
                    tint = Color.White,
                  )
                }
              }
            }
          }
        }
      }
    }

    // Portrait mode: quick channel/server switcher chips, Adsterra banner below player, and TV channel grid
    if (!isFullscreen) {
      Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(
                text = channel.name,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "${channel.category} • $resolutionText",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricEmerald,
              )
            }
            val isFav = channel.id in favoriteIds
            IconButton(
              onClick = { onToggleFavorite(channel.id) },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("player_favorite_button"),
            ) {
              Icon(
                imageVector = if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = stringResource(R.string.favorite_toggle),
                tint = if (isFav) LiveCrimson else MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          if (quickSwitchChannels.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
              contentPadding = PaddingValues(horizontal = 14.dp),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              items(items = quickSwitchChannels, key = { "qs_${it.id}" }) { ch ->
                val selected = ch.id == channel.id
                Surface(
                  onClick = { if (!selected) onSelectChannel(ch) },
                  shape = RoundedCornerShape(10.dp),
                  color = if (selected) Color(0xFFDCE4ED) else Color(0xFFF3F6FA),
                  border = if (selected) BorderStroke(1.5.dp, ElectricEmerald) else null,
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                  ) {
                    if (selected) {
                      Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = StadiumObsidian,
                        modifier = Modifier.size(14.dp),
                      )
                    }
                    Text(
                      text = ch.name,
                      style = MaterialTheme.typography.labelLarge,
                      color = StadiumObsidian,
                      maxLines = 1,
                    )
                  }
                }
              }
            }
          }
        }
      }

      BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val tvColumns = if (maxWidth >= 600.dp) 4 else 3
        LazyVerticalGrid(
          columns = GridCells.Fixed(tvColumns),
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(14.dp),
          horizontalArrangement = Arrangement.spacedBy(9.dp),
          verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
          // Adsterra Banner directly below the player (matching J TV SPORTS screenshot)
          item(span = { GridItemSpan(maxLineSpan) }) {
            AdsterraBannerAd()
          }

          item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
              text = stringResource(R.string.more_channels).uppercase(),
              style = MaterialTheme.typography.headlineSmall,
              color = Color.White,
            )
          }

          items(items = relatedChannels, key = { "rel_${it.id}" }) { other ->
            TvGridChannelCard(
              channel = other,
              isFavorite = other.id in favoriteIds,
              onPlayClick = { onSelectChannel(other) },
              onFavoriteClick = { onToggleFavorite(other.id) },
            )
          }
        }
      }
    }
  }

  if (showQualityDialog) {
    TrackQualityDialog(
      tracks = currentTracks,
      onDismiss = { showQualityDialog = false },
      onSelectAuto = { trackType ->
        exoPlayer.trackSelectionParameters =
          exoPlayer.trackSelectionParameters
            .buildUpon()
            .clearOverridesOfType(trackType)
            .setTrackTypeDisabled(trackType, false)
            .build()
        showQualityDialog = false
      },
      onDisableType = { trackType ->
        exoPlayer.trackSelectionParameters =
          exoPlayer.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(trackType, true)
            .build()
        showQualityDialog = false
      },
      onSelectOverride = { trackType, group, trackIndex ->
        exoPlayer.trackSelectionParameters =
          exoPlayer.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(trackType, false)
            .setOverrideForType(TrackSelectionOverride(group, trackIndex))
            .build()
        showQualityDialog = false
      },
    )
  }
}

@OptIn(UnstableApi::class)
@Composable
private fun TrackQualityDialog(
  tracks: Tracks,
  onDismiss: () -> Unit,
  onSelectAuto: (Int) -> Unit,
  onDisableType: (Int) -> Unit,
  onSelectOverride: (Int, TrackGroup, Int) -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0=VIDEO, 1=AUDIO, 2=TEXT
  val trackType =
    when (selectedTab) {
      0 -> C.TRACK_TYPE_VIDEO
      1 -> C.TRACK_TYPE_AUDIO
      else -> C.TRACK_TYPE_TEXT
    }

  val options = remember(tracks, trackType) {
    val list = mutableListOf<TrackOptionItem>()
    for (group in tracks.groups) {
      if (group.type != trackType) continue
      for (i in 0 until group.length) {
        if (!group.isTrackSupported(i)) continue
        val fmt = group.getTrackFormat(i)
        val label =
          when (trackType) {
            C.TRACK_TYPE_VIDEO -> {
              val res = if (fmt.width > 0 && fmt.height > 0) "${fmt.width} × ${fmt.height}" else "Video Track ${i + 1}"
              val mbps = if (fmt.bitrate > 0) String.format(", %.2f Mbps", fmt.bitrate / 1_000_000f) else ""
              "$res$mbps"
            }
            C.TRACK_TYPE_AUDIO -> {
              val lang = fmt.language ?: "Default"
              val ch = if (fmt.channelCount > 0) " (${fmt.channelCount}ch)" else ""
              "${fmt.label ?: lang}$ch"
            }
            else -> fmt.label ?: fmt.language ?: "Subtitle ${i + 1}"
          }
        list.add(
          TrackOptionItem(
            label = label,
            group = group.mediaTrackGroup,
            trackIndex = i,
            selected = group.isTrackSelected(i),
          ),
        )
      }
    }
    list
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Color.White,
    titleContentColor = Color.Black,
    textContentColor = Color.Black,
    title = null,
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = Color.White,
          contentColor = LiveCrimson,
        ) {
          Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("VIDEO") })
          Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("AUDIO") })
          Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("TEXT") })
        }
        Spacer(modifier = Modifier.height(8.dp))
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .clickable { onDisableType(trackType) }
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("None", color = Color.Black)
            RadioButton(selected = false, onClick = { onDisableType(trackType) })
          }
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .clickable { onSelectAuto(trackType) }
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("Auto", color = Color.Black)
            RadioButton(selected = options.none { it.selected }, onClick = { onSelectAuto(trackType) })
          }
          options.forEach { opt ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clickable {
                    if (opt.group != null) {
                      onSelectOverride(trackType, opt.group, opt.trackIndex)
                    }
                  }
                  .padding(vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(opt.label, color = Color.Black, modifier = Modifier.weight(1f))
              RadioButton(
                selected = opt.selected,
                onClick = {
                  if (opt.group != null) {
                    onSelectOverride(trackType, opt.group, opt.trackIndex)
                  }
                },
              )
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("OK", color = Color.Black)
      }
    },
  )
}

private tailrec fun Context.findActivity(): Activity? =
  when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
  }
