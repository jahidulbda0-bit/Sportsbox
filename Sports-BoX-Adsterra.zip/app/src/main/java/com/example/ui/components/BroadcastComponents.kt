package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Copyright
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ChannelCategorySummary
import com.example.data.model.LiveChannel
import com.example.data.model.MatchFixture
import com.example.data.model.MatchStatus
import com.example.ui.theme.BroadcastSlate
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.KriraLime
import com.example.ui.theme.LiveCrimson
import com.example.ui.theme.OutlineHighlight
import com.example.ui.theme.StadiumObsidian
import com.example.ui.theme.TrophyAmber

@Composable
fun LivePulseBadge(
  modifier: Modifier = Modifier,
  label: String = stringResource(R.string.live_badge),
  isLive: Boolean = true,
) {
  val transition = rememberInfiniteTransition(label = "live_pulse")
  val pulseAlpha by
    transition.animateFloat(
      initialValue = 1f,
      targetValue = 0.28f,
      animationSpec = infiniteRepeatable(animation = tween(750), repeatMode = RepeatMode.Reverse),
      label = "pulse_alpha",
    )

  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(6.dp),
    color = if (isLive) LiveCrimson else MaterialTheme.colorScheme.surfaceVariant,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
      if (isLive) {
        Box(
          modifier =
            Modifier.size(6.dp)
              .alpha(pulseAlpha)
              .clip(CircleShape)
              .background(Color.White),
        )
      }
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = Color.White,
        fontWeight = FontWeight.Bold,
      )
    }
  }
}

@Composable
fun SportsBoxTopBar(
  onMenuClick: () -> Unit,
  onSearchClick: () -> Unit,
  onRefreshClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    IconButton(
      onClick = onMenuClick,
      modifier = Modifier.minimumInteractiveComponentSize().testTag("drawer_menu_button"),
    ) {
      Icon(
        imageVector = Icons.Filled.Menu,
        contentDescription = stringResource(R.string.drawer_menu),
        tint = MaterialTheme.colorScheme.onBackground,
      )
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Box(
        modifier =
          Modifier.size(30.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Brush.linearGradient(listOf(KriraLime, ElectricEmerald))),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Tv,
          contentDescription = stringResource(R.string.app_name),
          tint = StadiumObsidian,
          modifier = Modifier.size(19.dp),
        )
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "Sports ",
          style = MaterialTheme.typography.headlineMedium,
          color = Color.White,
        )
        Text(
          text = "BoXBoX",
          style = MaterialTheme.typography.headlineMedium,
          color = ElectricEmerald,
        )
      }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(
        onClick = onRefreshClick,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("top_refresh_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.Refresh,
          contentDescription = stringResource(R.string.refresh),
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      IconButton(
        onClick = onSearchClick,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("top_search_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = stringResource(R.string.search_channels_hint),
          tint = MaterialTheme.colorScheme.onBackground,
        )
      }
    }
  }
}

@Composable
fun MatchBroadcastCard(
  match: MatchFixture,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val cardBrush =
    remember(match.status) {
      Brush.verticalGradient(
        colors =
          if (match.status == MatchStatus.LIVE) {
            listOf(Color(0xFF172742), Color(0xFF281628), Color(0xFF0E1B2E))
          } else {
            listOf(Color(0xFF132640), Color(0xFF0B182B))
          },
      )
    }

  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(MaterialTheme.shapes.large)
        .clickable(onClick = onClick)
        .testTag("match_card_${match.id}"),
    shape = MaterialTheme.shapes.large,
    border =
      BorderStroke(
        width = 1.dp,
        color =
          if (match.status == MatchStatus.LIVE) LiveCrimson.copy(alpha = 0.45f)
          else OutlineHighlight.copy(alpha = 0.55f),
      ),
    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().background(cardBrush).padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.SportsCricket,
            contentDescription = null,
            tint = ElectricEmerald,
            modifier = Modifier.size(15.dp),
          )
          Text(
            text = "${match.league}  •  ${match.sportCategory}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        if (match.isHot) {
          Icon(
            imageVector = Icons.Filled.LocalFireDepartment,
            contentDescription = "Hot match",
            tint = TrophyAmber,
            modifier = Modifier.size(18.dp),
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        MatchTeamBadgeColumn(
          name = match.team1,
          logoUrl = match.team1LogoUrl,
          modifier = Modifier.weight(1f),
        )

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.padding(horizontal = 8.dp),
        ) {
          when (match.status) {
            MatchStatus.LIVE -> LivePulseBadge(isLive = true)
            MatchStatus.UPCOMING -> {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
              ) {
                Text(
                  text = "UPCOMING",
                  style = MaterialTheme.typography.labelSmall,
                  color = ElectricEmerald,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                )
              }
            }
            MatchStatus.FINISHED -> {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
              ) {
                Text(
                  text = "ENDED",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                )
              }
            }
          }
          Text(
            text = match.matchTime,
            style = MaterialTheme.typography.labelMedium,
            color = if (match.status == MatchStatus.LIVE) Color(0xFFFF8894) else ElectricEmerald,
            maxLines = 1,
          )
        }

        MatchTeamBadgeColumn(
          name = match.team2,
          logoUrl = match.team2LogoUrl,
          modifier = Modifier.weight(1f),
        )
      }

      if (match.title.isNotBlank()) {
        Text(
          text = match.title,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
private fun MatchTeamBadgeColumn(
  name: String,
  logoUrl: String?,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(6.dp),
  ) {
    Surface(
      modifier = Modifier.size(46.dp),
      shape = CircleShape,
      color = Color.White,
    ) {
      if (!logoUrl.isNullOrBlank()) {
        AsyncImage(
          model = logoUrl,
          contentDescription = name,
          contentScale = ContentScale.Fit,
          modifier = Modifier.padding(4.dp).clip(CircleShape),
        )
      } else {
        Box(contentAlignment = Alignment.Center) {
          Text(
            text = name.take(2).uppercase(),
            style = MaterialTheme.typography.titleSmall,
            color = StadiumObsidian,
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }
    Text(
      text = name,
      style = MaterialTheme.typography.titleSmall,
      color = Color.White,
      textAlign = TextAlign.Center,
      maxLines = 2,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun ChannelCategoryCard(
  summary: ChannelCategorySummary,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .height(126.dp)
        .clip(MaterialTheme.shapes.medium)
        .clickable(onClick = onClick)
        .testTag("category_card_${summary.name}"),
    shape = MaterialTheme.shapes.medium,
    border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.28f)),
    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .fillMaxHeight()
          .background(
            Brush.verticalGradient(
              listOf(Color(0xFF132640), Color(0xFF0B1C2B), Color(0xFF0A2424)),
            ),
          )
          .padding(12.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Box(
        modifier = Modifier.fillMaxWidth().weight(1f),
        contentAlignment = Alignment.Center,
      ) {
        if (!summary.previewLogoUrl.isNullOrBlank()) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.White,
            modifier = Modifier.size(48.dp),
          ) {
            AsyncImage(
              model = summary.previewLogoUrl,
              contentDescription = summary.name,
              contentScale = ContentScale.Fit,
              modifier = Modifier.padding(4.dp),
            )
          }
        } else {
          Icon(
            imageVector = Icons.Filled.LiveTv,
            contentDescription = summary.name,
            tint = KriraLime,
            modifier = Modifier.size(40.dp),
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = summary.name,
          style = MaterialTheme.typography.titleSmall,
          color = Color.White,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f).padding(end = 6.dp),
        )
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = ElectricEmerald.copy(alpha = 0.16f),
          border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.45f)),
        ) {
          Text(
            text = summary.count.toString(),
            style = MaterialTheme.typography.labelSmall,
            color = ElectricEmerald,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
          )
        }
      }
    }
  }
}

@Composable
fun TvGridChannelCard(
  channel: LiveChannel,
  isFavorite: Boolean,
  onPlayClick: () -> Unit,
  onFavoriteClick: () -> Unit,
  modifier: Modifier = Modifier,
  onDeleteClick: (() -> Unit)? = null,
) {
  Card(
    modifier =
      modifier
        .fillMaxWidth()
        .clip(MaterialTheme.shapes.medium)
        .clickable(onClick = onPlayClick)
        .testTag("channel_card_${channel.id}"),
    shape = MaterialTheme.shapes.medium,
    border = BorderStroke(1.dp, ElectricEmerald.copy(alpha = 0.24f)),
    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(
            Brush.verticalGradient(
              listOf(Color(0xFF122740), Color(0xFF0A192A)),
            ),
          )
          .padding(horizontal = 6.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          shape = RoundedCornerShape(5.dp),
          color = StadiumObsidian.copy(alpha = 0.85f),
        ) {
          Text(
            text = channel.channelNumber,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (onDeleteClick != null) {
            IconButton(
              onClick = onDeleteClick,
              modifier = Modifier.size(34.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.DeleteOutline,
                contentDescription = stringResource(R.string.delete_stream),
                tint = LiveCrimson,
                modifier = Modifier.size(16.dp),
              )
            }
          }
          IconButton(
            onClick = onFavoriteClick,
            modifier = Modifier.minimumInteractiveComponentSize().size(36.dp).testTag("fav_btn_${channel.id}"),
          ) {
            Icon(
              imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
              contentDescription = stringResource(R.string.favorite_toggle),
              tint = if (isFavorite) LiveCrimson else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(17.dp),
            )
          }
        }
      }

      Surface(
        modifier = Modifier.size(56.dp),
        shape = RoundedCornerShape(10.dp),
        color = Color.White,
      ) {
        if (!channel.logoUrl.isNullOrBlank()) {
          AsyncImage(
            model = channel.logoUrl,
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.padding(4.dp),
          )
        } else {
          Box(
            modifier = Modifier.background(Color(0xFF1E3755)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.Tv,
              contentDescription = channel.name,
              tint = ElectricEmerald,
              modifier = Modifier.size(28.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(7.dp))

      Text(
        text = channel.name,
        style = MaterialTheme.typography.titleSmall,
        color = Color.White,
        textAlign = TextAlign.Center,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
      )

      Text(
        text = "● LIVE",
        style = MaterialTheme.typography.labelSmall,
        color = ElectricEmerald,
        modifier = Modifier.padding(top = 2.dp),
      )
    }
  }
}

data class FloatingNavItem(
  val label: String,
  val icon: ImageVector,
  val selected: Boolean,
  val testTag: String,
  val onClick: () -> Unit,
)

@Composable
fun FloatingBottomNavBar(
  items: List<FloatingNavItem>,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(horizontal = 18.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(32.dp),
      color = BroadcastSlate.copy(alpha = 0.96f),
      border = BorderStroke(1.dp, OutlineHighlight.copy(alpha = 0.65f)),
      shadowElevation = 10.dp,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        items.forEach { item ->
          val activeBrush =
            if (item.selected) {
              Brush.horizontalGradient(
                listOf(
                  ElectricEmerald.copy(alpha = 0.24f),
                  ElectricEmerald.copy(alpha = 0.10f),
                ),
              )
            } else {
              Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
            }

          Box(
            modifier =
              Modifier.weight(1f)
                .minimumInteractiveComponentSize()
                .clip(RoundedCornerShape(24.dp))
                .background(activeBrush)
                .clickable(onClick = item.onClick)
                .padding(vertical = 6.dp)
                .testTag(item.testTag),
            contentAlignment = Alignment.Center,
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
              Icon(
                imageVector = item.icon,
                contentDescription = item.label,
                tint = if (item.selected) ElectricEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(21.dp),
              )
              Text(
                text = item.label,
                style = MaterialTheme.typography.labelLarge,
                color = if (item.selected) ElectricEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun SportsBoxDrawerContent(
  onNavigateLive: () -> Unit,
  onNavigateChannels: () -> Unit,
  onNavigateHighlights: () -> Unit,
  onOpenAdminControl: () -> Unit,
  onOpenInfoDialog: (title: String, message: String) -> Unit,
  onShareApp: () -> Unit,
  onOpenTelegram: () -> Unit,
) {
  ModalDrawerSheet(
    drawerContainerColor = Color(0xFF101C2F),
    drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp),
    modifier = Modifier.width(296.dp),
  ) {
    Column(
      modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(16.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Column {
        Spacer(modifier = Modifier.height(12.dp))
        Column(
          modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier =
              Modifier.size(64.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(KriraLime, ElectricEmerald))),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.Tv,
              contentDescription = stringResource(R.string.app_name),
              tint = StadiumObsidian,
              modifier = Modifier.size(36.dp),
            )
          }
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "Sports BoXBoX",
            style = MaterialTheme.typography.headlineSmall,
            color = Color.White,
          )
          Text(
            text = "J TV SPORTS SYNCED",
            style = MaterialTheme.typography.labelSmall,
            color = ElectricEmerald,
          )
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Spacer(modifier = Modifier.height(8.dp))

        val itemColors =
          NavigationDrawerItemDefaults.colors(
            unselectedContainerColor = Color.Transparent,
            unselectedTextColor = Color.White,
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
          )

        NavigationDrawerItem(
          label = { Text(stringResource(R.string.admin_panel)) },
          selected = false,
          onClick = onOpenAdminControl,
          icon = { Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = ElectricEmerald) },
          colors = itemColors,
          modifier = Modifier.testTag("drawer_admin_control"),
        )
        NavigationDrawerItem(
          label = { Text("Live Matches") },
          selected = false,
          onClick = onNavigateLive,
          icon = { Icon(Icons.Filled.SportsSoccer, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text("Live TV Channels") },
          selected = false,
          onClick = onNavigateChannels,
          icon = { Icon(Icons.Filled.LiveTv, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text("Highlights & Favorites") },
          selected = false,
          onClick = onNavigateHighlights,
          icon = { Icon(Icons.Filled.PlayCircle, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text(stringResource(R.string.telegram_channel)) },
          selected = false,
          onClick = onOpenTelegram,
          icon = { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text(stringResource(R.string.privacy_policy)) },
          selected = false,
          onClick = {
            onOpenInfoDialog(
              "Privacy Policy",
              "Sports BoXBoX stores only your local favorite channel IDs, recent watch history, and optional custom stream URLs on your device via DataStore. Stream feeds are synced from your configured J TV Control API.",
            )
          },
          icon = { Icon(Icons.Filled.PrivacyTip, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text(stringResource(R.string.copyright_notice)) },
          selected = false,
          onClick = {
            onOpenInfoDialog(
              "Copyright",
              "Sports BoXBoX acts as a media stream player for channels and live feeds managed through your J TV Control backend. All trademarks and broadcast logos belong to their respective owners.",
            )
          },
          icon = { Icon(Icons.Filled.Copyright, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text(stringResource(R.string.disclaimer)) },
          selected = false,
          onClick = {
            onOpenInfoDialog(
              "Disclaimer",
              "Sports BoXBoX does not host video files directly on the device. All live channel URLs and match links are fetched dynamically from the connected control API.",
            )
          },
          icon = { Icon(Icons.Filled.Info, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text(stringResource(R.string.contact_us)) },
          selected = false,
          onClick = {
            onOpenInfoDialog(
              "Contact Us",
              "Website: jtvsports24.blogspot.com\nAdmin Sync Backend: j-tv-control-api.jahidul-bda0.workers.dev",
            )
          },
          icon = { Icon(Icons.Filled.Email, contentDescription = null) },
          colors = itemColors,
        )
        NavigationDrawerItem(
          label = { Text(stringResource(R.string.share_app)) },
          selected = false,
          onClick = onShareApp,
          icon = { Icon(Icons.Filled.Share, contentDescription = null) },
          colors = itemColors,
        )
      }

      Text(
        text = "Version: 1.0.0",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
      )
    }
  }
}

@Composable
fun AddCustomStreamDialog(
  onDismiss: () -> Unit,
  onSaveAndWatch: (name: String, url: String, category: String) -> Unit,
) {
  var name by remember { mutableStateOf("") }
  var url by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Sports") }
  var errorText by remember { mutableStateOf<String?>(null) }

  val categories = remember { listOf("Sports", "Bangladesh", "News", "Entertainment", "Custom") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = MaterialTheme.colorScheme.surface,
    title = {
      Text(
        text = stringResource(R.string.add_custom_stream),
        style = MaterialTheme.typography.headlineSmall,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = {
            name = it
            errorText = null
          },
          label = { Text(stringResource(R.string.channel_name_label)) },
          placeholder = { Text("e.g. T Sports HD") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("custom_name_input"),
        )
        OutlinedTextField(
          value = url,
          onValueChange = {
            url = it
            errorText = null
          },
          label = { Text(stringResource(R.string.stream_url_label)) },
          placeholder = { Text("https://.../stream.m3u8") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("custom_url_input"),
        )
        Text(
          text = stringResource(R.string.category_label),
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(categories) { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = cat },
              label = { Text(cat) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                  selectedLabelColor = MaterialTheme.colorScheme.primary,
                ),
            )
          }
        }
        if (errorText != null) {
          Text(
            text = errorText!!,
            style = MaterialTheme.typography.bodyMedium,
            color = LiveCrimson,
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val trimmedUrl = url.trim()
          val trimmedName = name.trim()
          when {
            trimmedName.isEmpty() -> errorText = "Please enter a channel name."
            !trimmedUrl.startsWith("http://", ignoreCase = true) &&
              !trimmedUrl.startsWith("https://", ignoreCase = true) ->
              errorText = "Enter a valid http:// or https:// stream URL."
            else -> onSaveAndWatch(trimmedName, trimmedUrl, selectedCategory)
          }
        },
        modifier = Modifier.testTag("save_custom_stream_button"),
      ) {
        Text(stringResource(R.string.save_and_watch))
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(stringResource(R.string.cancel))
      }
    },
  )
}
