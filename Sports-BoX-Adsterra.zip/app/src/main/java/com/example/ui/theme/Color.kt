package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StadiumObsidian = Color(0xFF050D19)
val BroadcastSlate = Color(0xFF0D1B2D)
val ElevatedArena = Color(0xFF10243B)
val HighestArena = Color(0xFF163150)

val ElectricEmerald = Color(0xFF00E5A0)
val KriraLime = Color(0xFF84CC16)
val DeepEmeraldContainer = Color(0xFF073B2F)
val OnElectricEmerald = Color(0xFF002117)

val LiveCrimson = Color(0xFFFF3448)
val CrimsonContainer = Color(0xFF47121C)

val TrophyAmber = Color(0xFFFFB800)
val AmberContainer = Color(0xFF3E2B00)

val TextPrimary = Color(0xFFF5F8FF)
val TextSecondary = Color(0xFF8FA5BF)
val OutlineSlate = Color(0xFF203953)
val OutlineHighlight = Color(0xFF2E5073)

// Light mode tokens
val LightStadiumSurface = Color(0xFFF5F8FC)
val LightCardSurface = Color(0xFFFFFFFF)
val LightElevatedSurface = Color(0xFFEAF1F9)
val LightPrimaryGreen = Color(0xFF007A55)
val LightTextPrimary = Color(0xFF091322)
val LightTextSecondary = Color(0xFF4A5D75)
