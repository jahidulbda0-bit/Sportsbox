package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val SportsBoxDarkColorScheme =
  darkColorScheme(
    primary = ElectricEmerald,
    onPrimary = OnElectricEmerald,
    primaryContainer = DeepEmeraldContainer,
    onPrimaryContainer = ElectricEmerald,
    secondary = LiveCrimson,
    onSecondary = Color.White,
    secondaryContainer = CrimsonContainer,
    onSecondaryContainer = Color(0xFFFFB3BE),
    tertiary = TrophyAmber,
    onTertiary = Color(0xFF231900),
    tertiaryContainer = AmberContainer,
    onTertiaryContainer = TrophyAmber,
    background = StadiumObsidian,
    onBackground = TextPrimary,
    surface = BroadcastSlate,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedArena,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = BroadcastSlate,
    surfaceContainer = ElevatedArena,
    surfaceContainerHigh = HighestArena,
    outline = OutlineSlate,
    outlineVariant = OutlineSlate,
  )

private val SportsBoxLightColorScheme =
  lightColorScheme(
    primary = LightPrimaryGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFBDFCE5),
    onPrimaryContainer = Color(0xFF002117),
    secondary = LiveCrimson,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDADE),
    onSecondaryContainer = Color(0xFF400010),
    tertiary = Color(0xFF8C5E00),
    onTertiary = Color.White,
    background = LightStadiumSurface,
    onBackground = LightTextPrimary,
    surface = LightCardSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightElevatedSurface,
    onSurfaceVariant = LightTextSecondary,
    outline = Color(0xFFC8D5E6),
  )

val JtvShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun JtvSportsTheme(
  darkTheme: Boolean = true,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) SportsBoxDarkColorScheme else SportsBoxLightColorScheme
  MaterialTheme(
    colorScheme = colorScheme,
    typography = JtvTypography,
    shapes = JtvShapes,
    content = content,
  )
}
