package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.LiveChannel
import com.example.data.model.MatchFixture
import com.example.data.model.MatchStatus
import com.example.ui.components.AdsterraBannerAd
import com.example.ui.components.LivePulseBadge
import com.example.ui.components.MatchBroadcastCard
import com.example.ui.components.TvGridChannelCard
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.LiveCrimson
import com.example.ui.viewmodel.MatchesUiState

@Composable
fun HighlightsScreen(
  allChannels: List<LiveChannel>,
  matchesState: MatchesUiState,
  favoriteIds: Set<String>,
  recentIds: List<String>,
  onChannelClick: (LiveChannel) -> Unit,
  onMatchClick: (MatchFixture) -> Unit,
  onToggleFavorite: (String) -> Unit,
  onDeleteCustomStream: (String) -> Unit,
  onAddStreamClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val favoriteChannels = allChannels.filter { it.id in favoriteIds }
  val customChannels = allChannels.filter { it.isCustom }
  val recentChannels = recentIds.mapNotNull { id -> allChannels.firstOrNull { it.id == id } }
  val finishedMatches =
    (matchesState as? MatchesUiState.Success)
      ?.matches
      ?.filter { it.status == MatchStatus.FINISHED && it.streamUrl.isNotBlank() }
      .orEmpty()

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val tvColumns = if (maxWidth >= 600.dp) 4 else 3

    LazyVerticalGrid(
      columns = GridCells.Fixed(tvColumns),
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 96.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item(span = { GridItemSpan(maxLineSpan) }) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "HIGHLIGHTS & SAVED",
              style = MaterialTheme.typography.headlineSmall,
            )
            Text(
              text = "Match replays, favorites & custom streams",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Button(
            onClick = onAddStreamClick,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.testTag("add_custom_stream_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.AddLink,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.open_stream_url))
          }
        }
      }

      item(span = { GridItemSpan(maxLineSpan) }) {
        AdsterraBannerAd()
      }

      if (recentChannels.isNotEmpty()) {
        item(span = { GridItemSpan(maxLineSpan) }) {
          Text(
            text = "RECENTLY WATCHED",
            style = MaterialTheme.typography.titleMedium,
            color = ElectricEmerald,
          )
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
          LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items = recentChannels, key = { "recent_${it.id}" }) { channel ->
              Surface(
                onClick = { onChannelClick(channel) },
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.width(190.dp),
              ) {
                Row(
                  modifier = Modifier.padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                  Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = ElectricEmerald,
                  )
                  Column(modifier = Modifier.weight(1f)) {
                    LivePulseBadge(isLive = true)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = channel.name,
                      style = MaterialTheme.typography.titleSmall,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                }
              }
            }
          }
        }
      }

      if (finishedMatches.isNotEmpty()) {
        item(span = { GridItemSpan(maxLineSpan) }) {
          Text(
            text = "MATCH HIGHLIGHTS",
            style = MaterialTheme.typography.titleMedium,
            color = ElectricEmerald,
          )
        }
        items(
          items = finishedMatches,
          key = { "hl_${it.id}" },
          span = { GridItemSpan(maxLineSpan) },
        ) { match ->
          MatchBroadcastCard(match = match, onClick = { onMatchClick(match) })
        }
      }

      if (customChannels.isNotEmpty()) {
        item(span = { GridItemSpan(maxLineSpan) }) {
          Text(
            text = "CUSTOM STREAMS",
            style = MaterialTheme.typography.titleMedium,
            color = ElectricEmerald,
          )
        }
        items(items = customChannels, key = { "custom_${it.id}" }) { channel ->
          TvGridChannelCard(
            channel = channel,
            isFavorite = channel.id in favoriteIds,
            onPlayClick = { onChannelClick(channel) },
            onFavoriteClick = { onToggleFavorite(channel.id) },
            onDeleteClick = { onDeleteCustomStream(channel.id) },
          )
        }
      }

      item(span = { GridItemSpan(maxLineSpan) }) {
        Text(
          text = "FAVORITE CHANNELS",
          style = MaterialTheme.typography.titleMedium,
          color = ElectricEmerald,
        )
      }

      if (favoriteChannels.isEmpty()) {
        item(span = { GridItemSpan(maxLineSpan) }) {
          Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.FavoriteBorder,
                contentDescription = null,
                tint = LiveCrimson,
                modifier = Modifier.size(38.dp),
              )
              Text(
                text = stringResource(R.string.no_highlights_title),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
              )
              Text(
                text = stringResource(R.string.no_highlights_tip),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
              )
            }
          }
        }
      } else {
        items(items = favoriteChannels, key = { "fav_${it.id}" }) { channel ->
          TvGridChannelCard(
            channel = channel,
            isFavorite = true,
            onPlayClick = { onChannelClick(channel) },
            onFavoriteClick = { onToggleFavorite(channel.id) },
          )
        }
      }
    }
  }
}
