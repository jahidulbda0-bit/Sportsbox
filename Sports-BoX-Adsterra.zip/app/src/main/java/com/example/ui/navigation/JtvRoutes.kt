package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable data object LiveMatchesRoute

@Serializable data object ChannelsRoute

@Serializable data object HighlightsRoute

@Serializable data class PlayerRoute(val channelId: String)

@Serializable data object AdminControlRoute
