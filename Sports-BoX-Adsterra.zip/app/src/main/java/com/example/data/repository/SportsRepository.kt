package com.example.data.repository

import com.example.data.local.StreamPreferencesRepository
import com.example.data.model.ChannelArtwork
import com.example.data.model.LiveChannel
import com.example.data.model.MatchFixture
import com.example.data.model.StreamType
import com.example.data.remote.JtvControlApi
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class SportsRepository(
  private val api: JtvControlApi,
  private val prefs: StreamPreferencesRepository,
) {

  val favoriteIds: Flow<Set<String>> = prefs.favoriteChannelIds
  val recentIds: Flow<List<String>> = prefs.recentChannelIds
  val customChannels: Flow<List<LiveChannel>> = prefs.customChannels
  val adminToken: Flow<String?> = prefs.adminToken

  suspend fun fetchRemoteChannels(): Result<List<LiveChannel>> = api.fetchChannels()

  suspend fun fetchRemoteMatches(): Result<List<MatchFixture>> = api.fetchMatches()

  suspend fun toggleFavorite(channelId: String) = prefs.toggleFavorite(channelId)

  suspend fun recordWatched(channelId: String) = prefs.recordWatched(channelId)

  suspend fun addCustomStream(
    name: String,
    url: String,
    category: String,
  ): LiveChannel {
    val cleanUrl = url.trim()
    val type = StreamType.detect(null, cleanUrl)
    val channel =
      LiveChannel(
        id = "custom_${UUID.randomUUID().toString().take(8)}",
        channelNumber = "USR",
        name = name.trim(),
        category = category.ifBlank { "Custom" },
        logoUrl = null,
        streamType = type,
        streamUrl = cleanUrl,
        sortOrder = -1,
        enabled = true,
        isCustom = true,
        artwork = ChannelArtwork.STADIUM_HERO,
      )
    prefs.addCustomChannel(channel)
    return channel
  }

  suspend fun removeCustomStream(channelId: String) = prefs.removeCustomChannel(channelId)

  suspend fun adminLogin(password: String): Result<String> =
    api.adminLogin(password).onSuccess { token -> prefs.saveAdminToken(token) }

  suspend fun adminLogout() = prefs.saveAdminToken(null)

  suspend fun adminFetchChannels(token: String): Result<List<LiveChannel>> =
    api.adminFetchChannels(token)

  suspend fun adminSaveChannel(
    token: String,
    existingId: String?,
    name: String,
    category: String,
    logoUrl: String,
    streamType: String,
    streamUrl: String,
    sortOrder: Int,
    enabled: Boolean,
  ): Result<Unit> =
    api.adminSaveChannel(
      token = token,
      existingId = existingId,
      name = name,
      category = category,
      logoUrl = logoUrl,
      streamType = streamType,
      streamUrl = streamUrl,
      sortOrder = sortOrder,
      enabled = enabled,
    )

  suspend fun adminDeleteChannel(token: String, channelId: String): Result<Unit> =
    api.adminDeleteChannel(token, channelId)

  suspend fun adminAddMatch(
    token: String,
    title: String,
    league: String,
    team1: String,
    team1Logo: String,
    team2: String,
    team2Logo: String,
    matchTime: String,
    status: String,
    streamType: String,
    streamUrl: String,
  ): Result<Unit> =
    api.adminAddMatch(
      token = token,
      title = title,
      league = league,
      team1 = team1,
      team1Logo = team1Logo,
      team2 = team2,
      team2Logo = team2Logo,
      matchTime = matchTime,
      status = status,
      streamType = streamType,
      streamUrl = streamUrl,
    )

  suspend fun adminDeleteMatch(token: String, matchId: String): Result<Unit> =
    api.adminDeleteMatch(token, matchId)
}
