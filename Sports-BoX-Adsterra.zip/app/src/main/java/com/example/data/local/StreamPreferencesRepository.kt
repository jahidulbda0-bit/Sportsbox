package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.LiveChannel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.sportsBoxDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "sports_boxbox_prefs")

class StreamPreferencesRepository(private val context: Context) {

  private val json = Json { ignoreUnknownKeys = true }

  private object Keys {
    val FAVORITE_IDS = stringSetPreferencesKey("favorite_channel_ids")
    val RECENT_IDS = stringPreferencesKey("recent_channel_ids_json")
    val CUSTOM_CHANNELS = stringPreferencesKey("custom_channels_json")
    val ADMIN_TOKEN = stringPreferencesKey("jtv_admin_token")
  }

  val favoriteChannelIds: Flow<Set<String>> =
    context.sportsBoxDataStore.data.map { prefs -> prefs[Keys.FAVORITE_IDS] ?: emptySet() }

  val recentChannelIds: Flow<List<String>> =
    context.sportsBoxDataStore.data.map { prefs ->
      val raw = prefs[Keys.RECENT_IDS] ?: return@map emptyList()
      runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    }

  val customChannels: Flow<List<LiveChannel>> =
    context.sportsBoxDataStore.data.map { prefs ->
      val raw = prefs[Keys.CUSTOM_CHANNELS] ?: return@map emptyList()
      runCatching { json.decodeFromString<List<LiveChannel>>(raw) }.getOrDefault(emptyList())
    }

  val adminToken: Flow<String?> =
    context.sportsBoxDataStore.data.map { prefs -> prefs[Keys.ADMIN_TOKEN] }

  suspend fun saveAdminToken(token: String?) {
    context.sportsBoxDataStore.edit { prefs ->
      if (token.isNullOrBlank()) prefs.remove(Keys.ADMIN_TOKEN)
      else prefs[Keys.ADMIN_TOKEN] = token
    }
  }

  suspend fun toggleFavorite(channelId: String) {
    context.sportsBoxDataStore.edit { prefs ->
      val current = prefs[Keys.FAVORITE_IDS] ?: emptySet()
      prefs[Keys.FAVORITE_IDS] =
        if (channelId in current) current - channelId else current + channelId
    }
  }

  suspend fun recordWatched(channelId: String) {
    context.sportsBoxDataStore.edit { prefs ->
      val current =
        prefs[Keys.RECENT_IDS]?.let {
          runCatching { json.decodeFromString<List<String>>(it) }.getOrNull()
        } ?: emptyList()
      val updated = (listOf(channelId) + current.filterNot { it == channelId }).take(10)
      prefs[Keys.RECENT_IDS] = json.encodeToString(updated)
    }
  }

  suspend fun addCustomChannel(channel: LiveChannel) {
    context.sportsBoxDataStore.edit { prefs ->
      val current =
        prefs[Keys.CUSTOM_CHANNELS]?.let {
          runCatching { json.decodeFromString<List<LiveChannel>>(it) }.getOrNull()
        } ?: emptyList()
      val updated = listOf(channel) + current
      prefs[Keys.CUSTOM_CHANNELS] = json.encodeToString(updated)
    }
  }

  suspend fun removeCustomChannel(channelId: String) {
    context.sportsBoxDataStore.edit { prefs ->
      val current =
        prefs[Keys.CUSTOM_CHANNELS]?.let {
          runCatching { json.decodeFromString<List<LiveChannel>>(it) }.getOrNull()
        } ?: emptyList()
      prefs[Keys.CUSTOM_CHANNELS] =
        json.encodeToString(current.filterNot { it.id == channelId })
      val favs = prefs[Keys.FAVORITE_IDS] ?: emptySet()
      if (channelId in favs) {
        prefs[Keys.FAVORITE_IDS] = favs - channelId
      }
    }
  }
}
